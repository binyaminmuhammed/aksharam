import { inscriptLayout, LayoutRow } from './inscript';
import { gistLayout } from './gist';
import { typewriterLayout } from './typewriter';
import { panchariLayout } from './panchari';
import { varityperLayout } from './varityper';
import { englishLayout } from './english';
import { KeyboardLayoutType } from '../../types';

export const keyboardLayouts: Record<KeyboardLayoutType, LayoutRow[]> = {
  inscript: inscriptLayout,
  gist: gistLayout,
  typewriter: typewriterLayout,
  panchari: panchariLayout,
  varityper: varityperLayout,
  english: englishLayout,
};

export const layoutLabels: Record<KeyboardLayoutType, string> = {
  inscript: 'Inscript',
  gist: 'GIST',
  typewriter: 'Typewriter',
  panchari: 'Panchari',
  varityper: 'Varityper',
  english: 'English',
};

// Map KeyboardEvent.code or physical key to the output character
export function getMappedCharacter(
  e: KeyboardEvent,
  layoutType: KeyboardLayoutType
): string | null {
  if (layoutType === 'english') {
    return null; // let default browser behavior handle English
  }

  // If holding Ctrl or Alt or Meta, do not intercept (let shortcuts like Ctrl+Z, Ctrl+S, Ctrl+C pass)
  if (e.ctrlKey || e.altKey || e.metaKey) {
    return null;
  }

  const layout = keyboardLayouts[layoutType];
  if (!layout) return null;

  for (const row of layout) {
    for (const key of row.keys) {
      if (key.code === e.code) {
        if (key.isSpecial && key.code !== 'Tab' && key.code !== 'Enter' && key.code !== 'Space') {
          return null;
        }
        if (e.shiftKey) {
          return key.shift || key.normal;
        }
        return key.normal;
      }
    }
  }

  return null;
}

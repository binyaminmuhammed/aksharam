import { KeyDefinition } from '../../types';

export interface LayoutRow {
  keys: KeyDefinition[];
}

export const inscriptLayout: LayoutRow[] = [
  {
    keys: [
      { code: 'Backquote', label: '` ~', normal: 'ൊ', shift: 'ഒ' },
      { code: 'Digit1', label: '1 !', normal: '1', shift: '!' },
      { code: 'Digit2', label: '2 @', normal: '2', shift: '@' },
      { code: 'Digit3', label: '3 #', normal: '3', shift: '#' },
      { code: 'Digit4', label: '4 $', normal: '4', shift: '$', alt: '₹' },
      { code: 'Digit5', label: '5 %', normal: '5', shift: '%' },
      { code: 'Digit6', label: '6 ^', normal: '6', shift: '^', alt: 'ന്റ' },
      { code: 'Digit7', label: '7 &', normal: '7', shift: '&', alt: 'ക്ഷ' },
      { code: 'Digit8', label: '8 *', normal: '8', shift: '*', alt: 'ശ്ര' },
      { code: 'Digit9', label: '9 (', normal: '9', shift: '(' },
      { code: 'Digit0', label: '0 )', normal: '0', shift: ')' },
      { code: 'Minus', label: '- _', normal: '-', shift: 'ഃ' },
      { code: 'Equal', label: '= +', normal: 'ൃ', shift: 'ഋ' },
      { code: 'Backspace', label: '⌫', normal: '', isSpecial: true, width: 'w-16' },
    ],
  },
  {
    keys: [
      { code: 'Tab', label: 'Tab ⇥', normal: '\t', isSpecial: true, width: 'w-14' },
      { code: 'KeyQ', label: 'Q', normal: 'ൌ', shift: 'ഔ' },
      { code: 'KeyW', label: 'W', normal: 'ൈ', shift: 'ഐ' },
      { code: 'KeyE', label: 'E', normal: 'ാ', shift: 'ആ' },
      { code: 'KeyR', label: 'R', normal: 'ീ', shift: 'ഈ' },
      { code: 'KeyT', label: 'T', normal: 'ൂ', shift: 'ഊ' },
      { code: 'KeyY', label: 'Y', normal: 'ബ', shift: 'ഭ' },
      { code: 'KeyU', label: 'U', normal: 'ഹ', shift: 'ങ' },
      { code: 'KeyI', label: 'I', normal: 'ഗ', shift: 'ഘ' },
      { code: 'KeyO', label: 'O', normal: 'ദ', shift: 'ധ' },
      { code: 'KeyP', label: 'P', normal: 'ജ', shift: 'ഝ' },
      { code: 'BracketLeft', label: '[ {', normal: 'ഡ', shift: 'ഢ' },
      { code: 'BracketRight', label: '] }', normal: 'ൊ', shift: 'ോ' },
      { code: 'Backslash', label: '\\ |', normal: '\u200C', shift: '\u200D', alt: 'zwnj' },
    ],
  },
  {
    keys: [
      { code: 'CapsLock', label: 'Caps Lock', normal: '', isSpecial: true, width: 'w-20' },
      { code: 'KeyA', label: 'A', normal: 'ോ', shift: 'ഓ' },
      { code: 'KeyS', label: 'S', normal: 'േ', shift: 'ഏ' },
      { code: 'KeyD', label: 'D', normal: '്', shift: 'അ' },
      { code: 'KeyF', label: 'F', normal: 'ി', shift: 'ഇ' },
      { code: 'KeyG', label: 'G', normal: 'ു', shift: 'ഉ' },
      { code: 'KeyH', label: 'H', normal: 'പ', shift: 'ഫ' },
      { code: 'KeyJ', label: 'J', normal: 'ര', shift: 'റ' },
      { code: 'KeyK', label: 'K', normal: 'ക', shift: 'ഖ' },
      { code: 'KeyL', label: 'L', normal: 'ത', shift: 'ഥ' },
      { code: 'Semicolon', label: '; :', normal: 'ച', shift: 'ഛ' },
      { code: 'Quote', label: "' \"", normal: 'ട', shift: 'ഠ' },
      { code: 'Enter', label: 'Enter ↵', normal: '\n', isSpecial: true, width: 'w-20' },
    ],
  },
  {
    keys: [
      { code: 'ShiftLeft', label: 'Shift ⇧', normal: '', isSpecial: true, width: 'w-24' },
      { code: 'KeyZ', label: 'Z', normal: 'െ', shift: 'എ' },
      { code: 'KeyX', label: 'X', normal: 'ം', shift: 'ൺ' },
      { code: 'KeyC', label: 'C', normal: 'മ', shift: 'ണ' },
      { code: 'KeyV', label: 'V', normal: 'ന', shift: 'ൻ' },
      { code: 'KeyB', label: 'B', normal: 'വ', shift: 'ഴ' },
      { code: 'KeyN', label: 'N', normal: 'ല', shift: 'ള' },
      { code: 'KeyM', label: 'M', normal: 'സ', shift: 'ശ' },
      { code: 'Comma', label: ', <', normal: ',', shift: 'ഷ' },
      { code: 'Period', label: '. >', normal: '.', shift: 'ൽ' },
      { code: 'Slash', label: '/ ?', normal: 'യ', shift: 'ൾ' },
      { code: 'ShiftRight', label: 'Shift ⇧', normal: '', isSpecial: true, width: 'w-24' },
    ],
  },
  {
    keys: [
      { code: 'ControlLeft', label: 'Ctrl', normal: '', isSpecial: true, width: 'w-16' },
      { code: 'AltLeft', label: 'Alt', normal: '', isSpecial: true, width: 'w-16' },
      { code: 'Space', label: 'Spacebar (സ്പേസ്)', normal: ' ', width: 'flex-1' },
      { code: 'AltRight', label: 'Alt', normal: '', isSpecial: true, width: 'w-16' },
      { code: 'KeyZWNJ', label: 'ZWNJ', normal: '\u200C', width: 'w-16' },
      { code: 'KeyZWJ', label: 'ZWJ', normal: '\u200D', width: 'w-16' },
    ],
  },
];

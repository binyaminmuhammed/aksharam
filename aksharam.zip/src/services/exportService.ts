import { Document, Paragraph, TextRun, HeadingLevel, Packer } from 'docx';

// Trigger download in browser
function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Export as TXT with UTF-8 BOM so Malayalam characters are preserved in all text editors
export function exportAsTxt(title: string, content: string) {
  const safeTitle = (title.trim() || 'Untitled_Malayalam_Document').replace(/[^a-zA-Z0-9_\u0D00-\u0D7F]/g, '_');
  const filename = `${safeTitle}.txt`;
  // Prepend UTF-8 BOM
  const blob = new Blob(['\uFEFF' + content], { type: 'text/plain;charset=utf-8' });
  triggerDownload(blob, filename);
}

// Export as Microsoft Word (.docx)
export async function exportAsDocx(title: string, content: string) {
  const safeTitle = (title.trim() || 'Untitled_Malayalam_Document').replace(/[^a-zA-Z0-9_\u0D00-\u0D7F]/g, '_');
  const filename = `${safeTitle}.docx`;

  const paragraphs: Paragraph[] = [
    new Paragraph({
      text: title,
      heading: HeadingLevel.TITLE,
      spacing: { after: 200 },
    }),
    new Paragraph({
      children: [
        new TextRun({
          text: `Created with Malayalam Writer • ${new Date().toLocaleDateString('ml-IN', { year: 'numeric', month: 'long', day: 'numeric' })}`,
          italics: true,
          color: '666666',
          size: 20,
        }),
      ],
      spacing: { after: 400 },
    }),
  ];

  const contentLines = content.split('\n');
  for (const line of contentLines) {
    paragraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text: line,
            size: 26,
            font: 'Noto Sans Malayalam',
          }),
        ],
        spacing: { after: 120, line: 360 },
      })
    );
  }

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: paragraphs,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  triggerDownload(blob, filename);
}

// Print document (or Save as PDF via browser print)
export function printDocument() {
  window.print();
}

// Share or Copy document link / text
export async function shareOrCopyDocument(title: string, content: string): Promise<{ success: boolean; message: string }> {
  if (navigator.share) {
    try {
      await navigator.share({
        title,
        text: content,
      });
      return { success: true, message: 'Shared successfully' };
    } catch {
      // Fall back to copying text
    }
  }

  try {
    await navigator.clipboard.writeText(content);
    return { success: true, message: 'Document text copied to clipboard' };
  } catch {
    return { success: false, message: 'Could not share or copy' };
  }
}


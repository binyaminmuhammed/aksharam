import { TranslationRequest, TranslationResponse } from '../types';

export const supportedSourceLanguages = [
  { code: 'auto', name: 'Auto Detect (തിരിച്ചറിയുക)' },
  { code: 'en', name: 'English (ഇംഗ്ലീഷ്)' },
  { code: 'hi', name: 'Hindi (ഹിന്ദി)' },
  { code: 'ta', name: 'Tamil (തമിഴ്)' },
  { code: 'te', name: 'Telugu (തെലുങ്ക്)' },
  { code: 'kn', name: 'Kannada (കന്നഡ)' },
  { code: 'bn', name: 'Bengali (ബംഗാളി)' },
  { code: 'mr', name: 'Marathi (മറാഠി)' },
  { code: 'gu', name: 'Gujarati (ഗുജറാത്തി)' },
  { code: 'ar', name: 'Arabic (അറബിക്)' },
  { code: 'fr', name: 'French (ഫ്രഞ്ച്)' },
  { code: 'de', name: 'German (ജർമ്മൻ)' },
  { code: 'es', name: 'Spanish (സ്പാനിഷ്)' },
  { code: 'ja', name: 'Japanese (ജാപ്പനീസ്)' },
  { code: 'zh', name: 'Chinese (ചൈനീസ്)' },
  { code: 'ko', name: 'Korean (കൊറിയൻ)' },
];

export async function translateToMalayalam(
  request: TranslationRequest
): Promise<TranslationResponse> {
  try {
    const res = await fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: request.text,
        sourceLanguage: request.sourceLanguage,
        targetLanguage: 'ml',
      }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Server responded with ${res.status}`);
    }

    return await res.json();
  } catch (error) {
    console.warn('Backend translation API error, attempting direct cloud translation...', error);
    return directCloudTranslate(request.text, request.sourceLanguage);
  }
}

// Decode HTML entities
function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

// Direct cloud translation fallback if local server is unreachable
async function directCloudTranslate(text: string, sourceLang: string): Promise<TranslationResponse> {
  const clean = text.trim();
  const lower = clean.toLowerCase();

  // If text is already Malayalam Unicode
  if (/^[\u0D00-\u0D7F\s\d.,!?'"()-]+$/.test(clean)) {
    return {
      translatedText: clean,
      detectedLanguage: 'Malayalam',
      provider: 'Direct Pass-through',
      isFallback: false,
    };
  }

  // Quick dictionary for offline/instant match
  const commonPhrases: Record<string, string> = {
    'hello': 'നമസ്കാരം',
    'welcome': 'സ്വാഗതം',
    'thank you': 'നന്ദി',
    'thanks': 'നന്ദി',
    'good morning': 'സുപ്രഭാതം',
    'good afternoon': 'ശുഭദിനം',
    'good evening': 'ശുഭസായാഹ്നം',
    'good night': 'ശുഭരാത്രി',
    'how are you': 'സുഖമാണോ?',
    'how are you?': 'സുഖമാണോ?',
    'i am fine': 'എനിക്ക് സുഖമാണ്',
    'yes': 'അതെ',
    'no': 'അല്ല',
    'malayalam': 'മലയാളം',
    'kerala': 'കേരളം',
    'love': 'സ്നേഹം',
    'peace': 'സമാധാനം',
  };

  if (commonPhrases[lower]) {
    return {
      translatedText: commonPhrases[lower],
      detectedLanguage: sourceLang === 'auto' ? 'English' : sourceLang,
      provider: 'Instant Dictionary',
      isFallback: false,
    };
  }

  // Direct fetch to neural translation service
  try {
    const langCode = sourceLang === 'auto' ? 'en' : sourceLang;
    const lines = text.split('\n');
    const translatedLines: string[] = [];

    for (const line of lines) {
      if (!line.trim()) {
        translatedLines.push('');
        continue;
      }
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(line)}&langpair=${langCode}|ml`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        if (data?.responseData?.translatedText) {
          translatedLines.push(decodeHtmlEntities(data.responseData.translatedText));
          continue;
        }
      }
      translatedLines.push(line);
    }

    return {
      translatedText: translatedLines.join('\n'),
      detectedLanguage: sourceLang === 'auto' ? 'Auto Detected' : sourceLang,
      provider: 'Cloud Translation Engine',
      isFallback: false,
    };
  } catch {
    return {
      translatedText: clean,
      detectedLanguage: sourceLang === 'auto' ? 'English' : sourceLang,
      provider: 'Offline Assistant',
      isFallback: true,
    };
  }
}

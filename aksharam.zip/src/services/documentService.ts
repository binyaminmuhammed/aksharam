import { DocumentItem, UserPreferences } from '../types';

const STORAGE_DOCS_KEY = 'malayalam_writer_docs_v1';
const STORAGE_PREFS_KEY = 'malayalam_writer_prefs_v1';
const STORAGE_ACTIVE_DOC_KEY = 'malayalam_writer_active_id_v1';

export const defaultPreferences: UserPreferences = {
  theme: 'system',
  keyboardLayout: 'inscript',
  showKeyboard: true,
  fontFamily: 'Noto Sans Malayalam',
  fontSize: 18,
  editorWidth: 'medium',
  keyboardSound: true,
  autosaveEnabled: true,
  defaultSourceLanguage: 'en',
  showMissionTracker: true,
  defaultWordGoal: 500,
};

export function getStats(text: string) {
  const trimmed = text.trim();
  const wordCount = trimmed === '' ? 0 : trimmed.split(/\s+/).length;
  const characterCount = text.length;
  const charsNoSpaces = text.replace(/\s/g, '').length;
  return { wordCount, characterCount, charsNoSpaces };
}

export const calculateDocumentStats = (text: string) => {
  const stats = getStats(text);
  return {
    words: stats.wordCount,
    chars: stats.characterCount,
    charsNoSpaces: stats.charsNoSpaces,
  };
};

export function createNewDocument(title = 'Untitled Malayalam Document', content = ''): DocumentItem {
  const now = new Date().toISOString();
  const stats = getStats(content);
  return {
    id: 'doc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    title,
    content,
    language: 'Malayalam',
    wordCount: stats.wordCount,
    characterCount: stats.characterCount,
    wordGoal: 500,
    missionTitle: 'എഴുത്ത് ദൗത്യം (Writing Mission)',
    isMissionActive: true,
    createdAt: now,
    updatedAt: now,
  };
}

export const createNewDocumentItem = createNewDocument;


export function loadDocuments(): DocumentItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_DOCS_KEY);
    if (!raw) {
      const initialDoc = createNewDocument(
        'മലയാളം എഴുത്തുപുര',
        'സ്വാഗതം! ഇവിടെ നിങ്ങൾക്ക് മലയാളത്തിൽ അനായാസം എഴുതാനും ടൈപ്പ് ചെയ്യാനും തർജ്ജമ ചെയ്യാനും സാധിക്കും.\n\nഇൻസ്ക്രിപ്റ്റ് (Inscript) കീബോർഡ് ഉപയോഗിച്ച് ടൈപ്പ് ചെയ്യുക അല്ലെങ്കിൽ ഓൺ-സ്ക്രീൻ കീബോർഡ് സഹായത്തോടെ എഴുതുക.'
      );
      saveDocuments([initialDoc]);
      return [initialDoc];
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load documents from localStorage', err);
    return [];
  }
}

export function saveDocuments(docs: DocumentItem[]) {
  try {
    localStorage.setItem(STORAGE_DOCS_KEY, JSON.stringify(docs));
  } catch (err) {
    console.error('Failed to save documents to localStorage', err);
  }
}

export function getActiveDocumentId(): string | null {
  try {
    return localStorage.getItem(STORAGE_ACTIVE_DOC_KEY);
  } catch {
    return null;
  }
}

export function setActiveDocumentId(id: string) {
  try {
    localStorage.setItem(STORAGE_ACTIVE_DOC_KEY, id);
  } catch {
    // Ignore error
  }
}

export function loadPreferences(): UserPreferences {
  try {
    const raw = localStorage.getItem(STORAGE_PREFS_KEY);
    if (!raw) return defaultPreferences;
    return { ...defaultPreferences, ...JSON.parse(raw) };
  } catch {
    return defaultPreferences;
  }
}

export function savePreferences(prefs: UserPreferences) {
  try {
    localStorage.setItem(STORAGE_PREFS_KEY, JSON.stringify(prefs));
  } catch {
    // Ignore error
  }
}

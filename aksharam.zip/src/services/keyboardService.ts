// Synthesized subtle keyboard click sound using Web Audio API
let audioCtx: AudioContext | null = null;

export function playKeyClickSound() {
  try {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    if (!audioCtx) return;

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(450, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, audioCtx.currentTime + 0.03);

    gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.03);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();
    osc.stop(audioCtx.currentTime + 0.03);
  } catch {
    // AudioContext blocked or not supported, ignore silently
  }
}

// Inserts text into a textarea at the exact cursor position, preserving selection and history
export function insertTextAtCursor(
  textarea: HTMLTextAreaElement,
  textToInsert: string
): { newText: string; newCursorPos: number } {
  const start = textarea.selectionStart ?? textarea.value.length;
  const end = textarea.selectionEnd ?? textarea.value.length;
  const value = textarea.value;

  const newText = value.substring(0, start) + textToInsert + value.substring(end);
  const newCursorPos = start + textToInsert.length;

  return { newText, newCursorPos };
}

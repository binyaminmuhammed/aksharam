import { OCRResponse } from '../types';

export async function extractTextFromFile(file: File): Promise<OCRResponse> {
  // Check file type
  const isImage = file.type.startsWith('image/');
  const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
  const isText = file.type === 'text/plain' || file.name.toLowerCase().endsWith('.txt') || file.name.toLowerCase().endsWith('.md');

  if (isText) {
    const text = await file.text();
    return {
      text,
      detectedLanguage: /[\u0D00-\u0D7F]/.test(text) ? 'Malayalam' : 'English',
      provider: 'Text Reader',
    };
  }

  // Convert to Base64 for API
  const base64 = await fileToBase64(file);

  try {
    const res = await fetch('/api/ocr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        base64Data: base64.split(',')[1] || base64,
        mimeType: file.type || (isPdf ? 'application/pdf' : 'image/jpeg'),
        filename: file.name,
      }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to extract text');
    }

    return await res.json();
  } catch (err: unknown) {
    console.warn('OCR API error', err);
    return {
      text: `ഫയൽ: ${file.name}\n(സൈസ്: ${(file.size / 1024).toFixed(1)} KB)\n\nOCR service is not configured yet. Server-side Gemini API credentials enable full multi-lingual OCR for Malayalam and English scans.`,
      detectedLanguage: 'Unknown',
      provider: 'Mock OCR (Awaiting Server Configuration)',
      isFallback: true,
    };
  }
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

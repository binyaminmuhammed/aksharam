import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  DocumentItem, 
  UserPreferences, 
  ThemeMode, 
  KeyboardLayoutType, 
  ToastMessage 
} from './types';
import { 
  loadDocuments, 
  saveDocuments, 
  loadPreferences, 
  savePreferences, 
  calculateDocumentStats,
  createNewDocumentItem
} from './services/documentService';
import { 
  exportAsTxt, 
  exportAsDocx, 
  printDocument, 
  shareOrCopyDocument 
} from './services/exportService';

// Layout & Components
import { AppHeader } from './components/layout/AppHeader';
import { WriterToolbar } from './components/writer/WriterToolbar';
import { DocumentHeader } from './components/writer/DocumentHeader';
import { MalayalamEditor, MalayalamEditorHandle } from './components/writer/MalayalamEditor';
import { EditorStatusBar } from './components/writer/EditorStatusBar';
import { KeyboardPanel } from './components/writer/KeyboardPanel';
import { FindBar } from './components/writer/FindBar';
import { ImportModal } from './components/writer/ImportModal';
import { WordMissionCard } from './components/writer/WordMissionCard';
import { TranslationWorkspace } from './components/translation/TranslationWorkspace';
import { OcrWorkspace } from './components/ocr/OcrWorkspace';
import { DocumentList } from './components/documents/DocumentList';
import { SettingsModal } from './components/settings/SettingsModal';
import { HelpModal } from './components/shared/HelpModal';
import { ToastContainer } from './components/shared/ToastContainer';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'writer' | 'translate' | 'documents' | 'ocr'>('writer');

  // Documents State
  const [documents, setDocuments] = useState<DocumentItem[]>(() => loadDocuments());
  const [activeDocId, setActiveDocId] = useState<string>(() => {
    const docs = loadDocuments();
    return docs[0]?.id || 'initial-doc';
  });

  // Current active document
  const activeDocument = documents.find((d) => d.id === activeDocId) || documents[0];
  const [content, setContent] = useState<string>(activeDocument?.content || '');
  const [title, setTitle] = useState<string>(activeDocument?.title || 'Untitled Malayalam Document');
  const [lastSaved, setLastSaved] = useState<Date | null>(new Date());
  const [isSaving, setIsSaving] = useState(false);

  // User Preferences
  const [preferences, setPreferences] = useState<UserPreferences>(() => loadPreferences());
  const [showKeyboard, setShowKeyboard] = useState<boolean>(preferences.showKeyboard);
  const [currentLayout, setCurrentLayout] = useState<KeyboardLayoutType>(preferences.keyboardLayout);
  const [showMissionTracker, setShowMissionTracker] = useState<boolean>(
    preferences.showMissionTracker !== undefined ? preferences.showMissionTracker : true
  );

  // Word Mission Goal state for active document
  const [wordGoal, setWordGoal] = useState<number>(activeDocument?.wordGoal || 500);
  const [missionTitle, setMissionTitle] = useState<string>(
    activeDocument?.missionTitle || 'എഴുത്ത് ദൗത്യം (Writing Mission)'
  );

  // Modals & Panels
  const [isFindOpen, setIsFindOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  // Find & Replace matches
  const [findMatchIndex, setFindMatchIndex] = useState(0);
  const [findTotalMatches, setFindTotalMatches] = useState(0);
  const findMatchesIndices = useRef<number[]>([]);

  // Undo / Redo History
  const [history, setHistory] = useState<string[]>([content]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const isHistoryUpdate = useRef(false);

  // Editor Ref
  const editorRef = useRef<MalayalamEditorHandle>(null);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((
    toastTitle: string, 
    desc?: string, 
    type: 'success' | 'error' | 'info' = 'info'
  ) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, title: toastTitle, description: desc, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync active document when activeDocId changes
  useEffect(() => {
    const doc = documents.find((d) => d.id === activeDocId);
    if (doc) {
      setContent(doc.content);
      setTitle(doc.title);
      setWordGoal(doc.wordGoal || 500);
      setMissionTitle(doc.missionTitle || 'എഴുത്ത് ദൗത്യം (Writing Mission)');
      setHistory([doc.content]);
      setHistoryIndex(0);
    }
  }, [activeDocId]);

  // Handle Theme application
  useEffect(() => {
    const applyTheme = () => {
      const prefersDark =
        typeof window !== 'undefined' &&
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: dark)').matches;

      const isDark =
        preferences.theme === 'dark' ||
        (preferences.theme === 'system' && prefersDark);

      if (isDark) {
        document.documentElement.classList.add('dark');
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.setAttribute('data-theme', 'light');
      }
    };

    applyTheme();

    if (preferences.theme === 'system' && typeof window !== 'undefined' && window.matchMedia) {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme();
      media.addEventListener('change', listener);
      return () => media.removeEventListener('change', listener);
    }
  }, [preferences.theme]);

  // Debounced Autosave to localStorage
  useEffect(() => {
    if (!preferences.autosaveEnabled) return;

    setIsSaving(true);
    const timer = setTimeout(() => {
      const stats = calculateDocumentStats(content);
      const updatedDocs = documents.map((doc) => {
        if (doc.id === activeDocId) {
          return {
            ...doc,
            title,
            content,
            wordCount: stats.words,
            characterCount: stats.chars,
            wordGoal,
            missionTitle,
            updatedAt: new Date().toISOString(),
          };
        }
        return doc;
      });

      setDocuments(updatedDocs);
      saveDocuments(updatedDocs);
      setIsSaving(false);
      setLastSaved(new Date());
    }, 800);

    return () => clearTimeout(timer);
  }, [content, title, wordGoal, missionTitle, activeDocId, preferences.autosaveEnabled]);

  // Handle content change & history
  const handleContentChange = (newContent: string) => {
    setContent(newContent);

    if (!isHistoryUpdate.current) {
      // Debounce history additions to avoid pushing every single keystroke
      const currentHistory = history.slice(0, historyIndex + 1);
      if (currentHistory[currentHistory.length - 1] !== newContent) {
        setHistory([...currentHistory, newContent]);
        setHistoryIndex(currentHistory.length);
      }
    }
    isHistoryUpdate.current = false;
  };

  // History Undo & Redo
  const handleUndo = () => {
    if (historyIndex > 0) {
      isHistoryUpdate.current = true;
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      setContent(prev);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      isHistoryUpdate.current = true;
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      setContent(next);
    }
  };

  // Document Operations
  const handleNewDocument = () => {
    const newDoc = createNewDocumentItem();
    const updated = [newDoc, ...documents];
    setDocuments(updated);
    saveDocuments(updated);
    setActiveDocId(newDoc.id);
    setActiveTab('writer');
    showToast('New Document created', newDoc.title, 'success');
  };

  const handleOpenDocuments = () => {
    setActiveTab('documents');
  };

  const handleSaveImmediate = () => {
    const stats = calculateDocumentStats(content);
    const updatedDocs = documents.map((doc) => {
      if (doc.id === activeDocId) {
        return {
          ...doc,
          title,
          content,
          wordCount: stats.words,
          characterCount: stats.chars,
          wordGoal,
          missionTitle,
          updatedAt: new Date().toISOString(),
        };
      }
      return doc;
    });

    setDocuments(updatedDocs);
    saveDocuments(updatedDocs);
    setIsSaving(false);
    setLastSaved(new Date());
    showToast('Document saved', title, 'success');
  };

  // Word Mission Goal handlers
  const handleUpdateGoal = (newGoal: number) => {
    const safeGoal = Math.max(10, newGoal);
    setWordGoal(safeGoal);
    const updatedDocs = documents.map((doc) =>
      doc.id === activeDocId ? { ...doc, wordGoal: safeGoal } : doc
    );
    setDocuments(updatedDocs);
    saveDocuments(updatedDocs);
    showToast('Word Goal updated', `${safeGoal} words target`, 'info');
  };

  const handleUpdateMissionTitle = (newTitle: string) => {
    setMissionTitle(newTitle);
    const updatedDocs = documents.map((doc) =>
      doc.id === activeDocId ? { ...doc, missionTitle: newTitle } : doc
    );
    setDocuments(updatedDocs);
    saveDocuments(updatedDocs);
    showToast('Mission updated', newTitle, 'info');
  };

  const handleClear = () => {
    if (!content.trim()) return;
    if (window.confirm('Are you sure you want to clear this document?')) {
      handleContentChange('');
      showToast('Document cleared', undefined, 'info');
    }
  };

  const handleCopy = () => {
    if (!content) {
      showToast('Nothing to copy', undefined, 'error');
      return;
    }
    navigator.clipboard.writeText(content);
    showToast('Copied to clipboard', 'Full document text copied', 'success');
  };

  const handleShare = async () => {
    const result = await shareOrCopyDocument(title, content);
    showToast(result.message, undefined, 'info');
  };

  const handleDownloadTxt = () => {
    exportAsTxt(title, content);
    showToast('Downloaded text file', `${title}.txt`, 'success');
  };

  const handleDownloadDocx = () => {
    exportAsDocx(title, content);
    showToast('Downloaded Word document', `${title}.docx`, 'success');
  };

  const handlePrint = () => {
    printDocument();
  };

  // Find & Replace implementation
  const handleFind = (query: string, direction: 'next' | 'prev') => {
    if (!query) {
      setFindTotalMatches(0);
      findMatchesIndices.current = [];
      return;
    }

    const indices: number[] = [];
    let pos = 0;
    const lowerContent = content.toLowerCase();
    const lowerQuery = query.toLowerCase();

    while ((pos = lowerContent.indexOf(lowerQuery, pos)) !== -1) {
      indices.push(pos);
      pos += lowerQuery.length;
    }

    findMatchesIndices.current = indices;
    setFindTotalMatches(indices.length);

    if (indices.length > 0) {
      let nextIdx = findMatchIndex;
      if (direction === 'next') {
        nextIdx = (findMatchIndex + 1) % indices.length;
      } else {
        nextIdx = (findMatchIndex - 1 + indices.length) % indices.length;
      }
      setFindMatchIndex(nextIdx);

      const targetPos = indices[nextIdx];
      editorRef.current?.selectRange(targetPos, targetPos + query.length);
    }
  };

  const handleReplace = (query: string, replacement: string, replaceAll: boolean) => {
    if (!query) return;

    if (replaceAll) {
      const updated = content.replaceAll(query, replacement);
      handleContentChange(updated);
      showToast('Replaced all occurrences', undefined, 'success');
      handleFind(query, 'next');
    } else {
      if (findMatchesIndices.current.length > 0) {
        const targetPos = findMatchesIndices.current[findMatchIndex];
        const updated =
          content.substring(0, targetPos) +
          replacement +
          content.substring(targetPos + query.length);
        handleContentChange(updated);
        showToast('Replaced occurrence', undefined, 'success');
        setTimeout(() => handleFind(query, 'next'), 10);
      }
    }
  };

  // Import Modal Insert handler
  const handleImportInsert = (text: string, mode: 'replace' | 'append') => {
    if (mode === 'replace') {
      handleContentChange(text);
    } else {
      handleContentChange(content ? `${content}\n\n${text}` : text);
    }
    setActiveTab('writer');
    showToast('Imported and inserted into Writer', undefined, 'success');
  };

  // "Send to Writer" from Translation or OCR
  const handleSendToWriter = (text: string) => {
    if (!content.trim()) {
      handleContentChange(text);
    } else {
      handleContentChange(`${content}\n\n${text}`);
    }
    setActiveTab('writer');
    showToast('Sent to Writer', 'Text appended to current document', 'success');
  };

  // Documents page handlers
  const handleRenameDocument = (id: string, newTitle: string) => {
    const updated = documents.map((d) => (d.id === id ? { ...d, title: newTitle } : d));
    setDocuments(updated);
    saveDocuments(updated);
    if (id === activeDocId) setTitle(newTitle);
  };

  const handleDuplicateDocument = (doc: DocumentItem) => {
    const dup: DocumentItem = {
      ...doc,
      id: 'doc_' + Date.now(),
      title: `${doc.title} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [dup, ...documents];
    setDocuments(updated);
    saveDocuments(updated);
    showToast('Document duplicated', dup.title, 'success');
  };

  const handleDeleteDocument = (id: string) => {
    if (documents.length <= 1) {
      showToast('Cannot delete', 'You must have at least one document', 'error');
      return;
    }
    if (window.confirm('Delete this document?')) {
      const updated = documents.filter((d) => d.id !== id);
      setDocuments(updated);
      saveDocuments(updated);
      if (id === activeDocId) {
        setActiveDocId(updated[0].id);
      }
      showToast('Document deleted', undefined, 'info');
    }
  };

  // Update Preferences
  const handleUpdatePreferences = (newPrefs: Partial<UserPreferences>) => {
    const updated = { ...preferences, ...newPrefs };
    setPreferences(updated);
    savePreferences(updated);
    if (newPrefs.showKeyboard !== undefined) {
      setShowKeyboard(newPrefs.showKeyboard);
    }
    if (newPrefs.keyboardLayout !== undefined) {
      setCurrentLayout(newPrefs.keyboardLayout);
    }
  };

  // Calculate live stats
  const stats = calculateDocumentStats(content);

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 flex flex-col font-sans transition-colors">
      {/* Top Application Navigation */}
      <AppHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        showKeyboard={showKeyboard}
        setShowKeyboard={setShowKeyboard}
        theme={preferences.theme}
        setTheme={(m: ThemeMode) => {
          handleUpdatePreferences({ theme: m });
          const isDarkSys = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
          showToast(
            `Theme: ${m === 'dark' ? 'Dark Mode' : m === 'light' ? 'Light Mode' : 'System Default'}`,
            m === 'system' ? `Device appearance is currently ${isDarkSys ? 'Dark' : 'Light'}` : undefined,
            'info'
          );
        }}
        openSettings={() => setIsSettingsOpen(true)}
        openHelp={() => setIsHelpOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col w-full relative">
        {activeTab === 'writer' && (
          <div className="flex-1 flex flex-col max-w-7xl w-full mx-auto p-3 sm:p-4 gap-2">
            {/* Writer Toolbar */}
            <WriterToolbar
              onNew={handleNewDocument}
              onOpen={handleOpenDocuments}
              onSave={handleSaveImmediate}
              onDownloadTxt={handleDownloadTxt}
              onDownloadDocx={handleDownloadDocx}
              onPrint={handlePrint}
              onCopy={handleCopy}
              onClear={handleClear}
              onUndo={handleUndo}
              onRedo={handleRedo}
              canUndo={historyIndex > 0}
              canRedo={historyIndex < history.length - 1}
              onToggleFind={() => setIsFindOpen(!isFindOpen)}
              onGoToTranslate={() => setActiveTab('translate')}
              onShare={handleShare}
              onOpenImport={() => setIsImportOpen(true)}
              onToggleMission={() => setShowMissionTracker(!showMissionTracker)}
              showMission={showMissionTracker}
              wordGoalProgress={{
                current: stats.words,
                goal: wordGoal,
                percentage: Math.min(100, Math.round((stats.words / Math.max(1, wordGoal)) * 100)),
              }}
            />

            {/* Writing Word Goal Mission Section */}
            {showMissionTracker && (
              <WordMissionCard
                currentWordCount={stats.words}
                wordGoal={wordGoal}
                missionTitle={missionTitle}
                onUpdateGoal={handleUpdateGoal}
                onUpdateTitle={handleUpdateMissionTitle}
                onClose={() => setShowMissionTracker(false)}
              />
            )}

            {/* Document Header (Title rename & autosave indicator) */}
            <DocumentHeader
              title={title}
              onTitleChange={setTitle}
              isSaving={isSaving}
              lastSaved={lastSaved}
            />

            {/* Find and Replace bar */}
            <FindBar
              isOpen={isFindOpen}
              onClose={() => setIsFindOpen(false)}
              onFind={handleFind}
              onReplace={handleReplace}
              matchIndex={findMatchIndex}
              totalMatches={findTotalMatches}
            />

            {/* Main Document Editor Surface */}
            <MalayalamEditor
              ref={editorRef}
              content={content}
              onChange={handleContentChange}
              layout={currentLayout}
              fontFamily={preferences.fontFamily}
              fontSize={preferences.fontSize}
              editorWidth={preferences.editorWidth}
              soundEnabled={preferences.keyboardSound}
              onSaveShortcut={handleSaveImmediate}
              onFindShortcut={() => setIsFindOpen(true)}
              onPrintShortcut={handlePrint}
              onNewShortcut={handleNewDocument}
              onUndoShortcut={handleUndo}
              onRedoShortcut={handleRedo}
            />

            {/* Bottom Status Bar */}
            <EditorStatusBar
              wordCount={stats.words}
              characterCount={stats.chars}
              charsNoSpaces={stats.charsNoSpaces}
              currentLayout={currentLayout}
              onLayoutChange={setCurrentLayout}
              showKeyboard={showKeyboard}
              onToggleKeyboard={() => setShowKeyboard(!showKeyboard)}
              wordGoal={wordGoal}
              onToggleMission={() => setShowMissionTracker(!showMissionTracker)}
            />

            {/* Interactive On-Screen Malayalam Keyboard Panel */}
            {showKeyboard && (
              <KeyboardPanel
                currentLayout={currentLayout}
                onLayoutChange={setCurrentLayout}
                onKeyPress={(char) => editorRef.current?.insertText(char)}
                onBackspace={() => editorRef.current?.deleteBackward()}
                onEnter={() => editorRef.current?.insertNewline()}
                onClose={() => setShowKeyboard(false)}
                soundEnabled={preferences.keyboardSound}
                onToggleSound={() =>
                  handleUpdatePreferences({ keyboardSound: !preferences.keyboardSound })
                }
              />
            )}
          </div>
        )}

        {activeTab === 'translate' && (
          <TranslationWorkspace
            onSendToWriter={handleSendToWriter}
            showToast={showToast}
          />
        )}

        {activeTab === 'documents' && (
          <DocumentList
            documents={documents}
            activeDocId={activeDocId}
            onSelectDocument={(doc) => {
              setActiveDocId(doc.id);
              setActiveTab('writer');
            }}
            onCreateNew={handleNewDocument}
            onRename={handleRenameDocument}
            onDuplicate={handleDuplicateDocument}
            onDelete={handleDeleteDocument}
            showToast={showToast}
          />
        )}

        {activeTab === 'ocr' && (
          <OcrWorkspace
            onSendToWriter={handleSendToWriter}
            showToast={showToast}
          />
        )}
      </main>

      {/* Modals & Dialogs */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        hasExistingText={Boolean(content.trim())}
        onInsertText={handleImportInsert}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
      />

      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
      />

      {/* Floating Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

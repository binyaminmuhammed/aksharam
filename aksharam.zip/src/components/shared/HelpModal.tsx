import React, { useState, useMemo } from 'react';
import { 
  X, 
  BookOpen, 
  Keyboard, 
  Command, 
  Sparkles, 
  Copy, 
  Check, 
  Search, 
  Lightbulb, 
  Layers, 
  Zap,
  Cpu
} from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ConjunctItem {
  char: string;
  name: string;
  formula: string;
  keys: string;
  category: 'velar' | 'palatal' | 'retroflex' | 'dental' | 'labial' | 'liquids' | 'geminate';
}

const CONJUNCTS_DATA: ConjunctItem[] = [
  // Velar & gutturals (ക വർഗ്ഗം)
  { char: 'ക്ക', name: 'ക്ക (ക + ക)', formula: 'ക (k) + ് (d) + ക (k)', keys: 'k + d + k', category: 'geminate' },
  { char: 'ക്ട', name: 'ക്ട (ക + ട)', formula: "ക (k) + ് (d) + ട (')", keys: "k + d + '", category: 'velar' },
  { char: 'ക്ത', name: 'ക്ത (ക + ത)', formula: 'ക (k) + ് (d) + ത (l)', keys: 'k + d + l', category: 'velar' },
  { char: 'ക്ഷ', name: 'ക്ഷ (ക + ഷ)', formula: 'ക (k) + ് (d) + ഷ (<)', keys: 'k + d + <', category: 'velar' },
  { char: 'ക്ല', name: 'ക്ല (ക + ല)', formula: 'ക (k) + ് (d) + ല (n)', keys: 'k + d + n', category: 'liquids' },
  { char: 'ക്വ', name: 'ക്വ (ക + വ)', formula: 'ക (k) + ് (d) + വ (b)', keys: 'k + d + b', category: 'liquids' },
  { char: 'ങ്ക', name: 'ങ്ക (ങ + ക)', formula: 'ങ (U) + ് (d) + ക (k)', keys: 'U + d + k', category: 'velar' },
  { char: 'ങ്ങ', name: 'ങ്ങ (ങ + ങ)', formula: 'ങ (U) + ് (d) + ങ (U)', keys: 'U + d + U', category: 'geminate' },
  { char: 'ഗ്ഗ', name: 'ഗ്ഗ (ഗ + ഗ)', formula: 'ഗ (i) + ് (d) + ഗ (i)', keys: 'i + d + i', category: 'geminate' },
  { char: 'ഗ്ദ്ധ', name: 'ഗ്ദ്ധ (ഗ + ധ)', formula: 'ഗ (i) + ് (d) + ധ (O)', keys: 'i + d + O', category: 'velar' },
  { char: 'ഗ്ന', name: 'ഗ്ന (ഗ + ന)', formula: 'ഗ (i) + ് (d) + ന (v)', keys: 'i + d + v', category: 'velar' },

  // Palatal (ച വർഗ്ഗം)
  { char: 'ച്ച', name: 'ച്ച (ച + ച)', formula: 'ച (p) + ് (d) + ച (p)', keys: 'p + d + p', category: 'geminate' },
  { char: 'ഞ്ച', name: 'ഞ്ച (ഞ + ച)', formula: 'ഞ (}) + ് (d) + ച (p)', keys: '} + d + p', category: 'palatal' },
  { char: 'ഞ്ഞ', name: 'ഞ്ഞ (ഞ + ഞ)', formula: 'ഞ (}) + ് (d) + ഞ (})', keys: '} + d + }', category: 'geminate' },
  { char: 'ജ്ജ', name: 'ജ്ജ (ജ + ജ)', formula: 'ജ (;) + ് (d) + ജ (;)', keys: '; + d + ;', category: 'geminate' },
  { char: 'ജ്ഞ', name: 'ജ്ഞ (ജ + ഞ)', formula: 'ജ (;) + ് (d) + ഞ (})', keys: '; + d + }', category: 'palatal' },
  { char: 'ശ്ച', name: 'ശ്ച (ശ + ച)', formula: 'ശ (M) + ് (d) + ച (p)', keys: 'M + d + p', category: 'palatal' },

  // Retroflex (ട വർഗ്ഗം)
  { char: 'ട്ട', name: 'ട്ട (ട + ട)', formula: "ട (') + ് (d) + ട (')", keys: "' + d + '", category: 'geminate' },
  { char: 'ണ്ട', name: 'ണ്ട (ണ + ട)', formula: "ണ (C) + ് (d) + ട (')", keys: "C + d + '", category: 'retroflex' },
  { char: 'ണ്ഠ', name: 'ണ്ഠ (ണ + ഠ)', formula: 'ണ (C) + ് (d) + ഠ (")', keys: 'C + d + "', category: 'retroflex' },
  { char: 'ണ്ണ', name: 'ണ്ണ (ണ + ണ)', formula: 'ണ (C) + ് (d) + ണ (C)', keys: 'C + d + C', category: 'geminate' },
  { char: 'ഷ്ട', name: 'ഷ്ട (ഷ + ട)', formula: "ഷ (<) + ് (d) + ട (')", keys: "< + d + '", category: 'retroflex' },
  { char: 'ഷ്ഠ', name: 'ഷ്ഠ (ഷ + ഠ)', formula: 'ഷ (<) + ് (d) + ഠ (")', keys: '< + d + "', category: 'retroflex' },
  { char: 'ഷ്ണ', name: 'ഷ്ണ (ഷ + ണ)', formula: 'ഷ (<) + ് (d) + ണ (C)', keys: '< + d + C', category: 'retroflex' },
  { char: 'ണ്ഡ', name: 'ണ്ഡ (ണ + ഡ)', formula: 'ണ (C) + ് (d) + ഡ ([)', keys: 'C + d + [', category: 'retroflex' },

  // Dental (ത വർഗ്ഗം)
  { char: 'ത്ത', name: 'ത്ത (ത + ത)', formula: 'ത (l) + ് (d) + ത (l)', keys: 'l + d + l', category: 'geminate' },
  { char: 'ത്ഥ', name: 'ത്ഥ (ത + ഥ)', formula: 'ത (l) + ് (d) + ഥ (L)', keys: 'l + d + L', category: 'dental' },
  { char: 'ന്ത', name: 'ന്ത (ന + ത)', formula: 'ന (v) + ് (d) + ത (l)', keys: 'v + d + l', category: 'dental' },
  { char: 'ന്ദ', name: 'ന്ദ (ന + ദ)', formula: 'ന (v) + ് (d) + ദ (o)', keys: 'v + d + o', category: 'dental' },
  { char: 'ന്ധ', name: 'ന്ധ (ന + ധ)', formula: 'ന (v) + ് (d) + ധ (O)', keys: 'v + d + O', category: 'dental' },
  { char: 'ന്ന', name: 'ന്ന (ന + ന)', formula: 'ന (v) + ് (d) + ന (v)', keys: 'v + d + v', category: 'geminate' },
  { char: 'ത്മ', name: 'ത്മ (ത + മ)', formula: 'ത (l) + ് (d) + മ (c)', keys: 'l + d + c', category: 'dental' },
  { char: 'ത്സ', name: 'ത്സ (ത + സ)', formula: 'ത (l) + ് (d) + സ (m)', keys: 'l + d + m', category: 'dental' },
  { char: 'ദ്ധ', name: 'ദ്ധ (ദ + ധ)', formula: 'ദ (o) + ് (d) + ധ (O)', keys: 'o + d + O', category: 'dental' },

  // Labial (പ വർഗ്ഗം)
  { char: 'പ്പ', name: 'പ്പ (പ + പ)', formula: 'പ (h) + ് (d) + പ (h)', keys: 'h + d + h', category: 'geminate' },
  { char: 'മ്പ', name: 'മ്പ (മ + പ)', formula: 'മ (c) + ് (d) + പ (h)', keys: 'c + d + h', category: 'labial' },
  { char: 'മ്മ', name: 'മ്മ (മ + മ)', formula: 'മ (c) + ് (d) + മ (c)', keys: 'c + d + c', category: 'geminate' },
  { char: 'ബ്ബ', name: 'ബ്ബ (ബ + ബ)', formula: 'ബ (y) + ് (d) + ബ (y)', keys: 'y + d + y', category: 'geminate' },
  { char: 'ബ്ധ', name: 'ബ്ധ (ബ + ധ)', formula: 'ബ (y) + ് (d) + ധ (O)', keys: 'y + d + O', category: 'labial' },
  { char: 'പ്ല', name: 'പ്ല (പ + ല)', formula: 'പ (h) + ് (d) + ല (n)', keys: 'h + d + n', category: 'liquids' },

  // Consonants with R (ര / ്ര - Ra conjuncts)
  { char: 'പ്ര', name: 'പ്ര (പ + ര)', formula: 'പ (h) + ് (d) + ര (j)', keys: 'h + d + j', category: 'liquids' },
  { char: 'ത്ര', name: 'ത്ര (ത + ര)', formula: 'ത (l) + ് (d) + ര (j)', keys: 'l + d + j', category: 'liquids' },
  { char: 'ക്ര', name: 'ക്ര (ക + ര)', formula: 'ക (k) + ് (d) + ര (j)', keys: 'k + d + j', category: 'liquids' },
  { char: 'ഗ്ര', name: 'ഗ്ര (ഗ + ര)', formula: 'ഗ (i) + ് (d) + ര (j)', keys: 'i + d + j', category: 'liquids' },
  { char: 'ദ്ര', name: 'ദ്ര (ദ + ര)', formula: 'ദ (o) + ് (d) + ര (j)', keys: 'o + d + j', category: 'liquids' },
  { char: 'ധ്ര', name: 'ധ്ര (ധ + ര)', formula: 'ധ (O) + ് (d) + ര (j)', keys: 'O + d + j', category: 'liquids' },
  { char: 'ബ്ര', name: 'ബ്ര (ബ + ര)', formula: 'ബ (y) + ് (d) + ര (j)', keys: 'y + d + j', category: 'liquids' },
  { char: 'മ്ര', name: 'മ്ര (മ + ര)', formula: 'മ (c) + ് (d) + ര (j)', keys: 'c + d + j', category: 'liquids' },
  { char: 'ശ്ര', name: 'ശ്ര (ശ + ര)', formula: 'ശ (M) + ് (d) + ര (j)', keys: 'M + d + j', category: 'liquids' },
  { char: 'സ്ര', name: 'സ്ര (സ + ര)', formula: 'സ (m) + ് (d) + ര (j)', keys: 'm + d + j', category: 'liquids' },
  { char: 'ഹ്ര', name: 'ഹ്ര (ഹ + ര)', formula: 'ഹ (u) + ് (d) + ര (j)', keys: 'u + d + j', category: 'liquids' },

  // Consonants with Y (യ / ്യ - Ya conjuncts)
  { char: 'ക്യ', name: 'ക്യ (ക + യ)', formula: 'ക (k) + ് (d) + യ (/)', keys: 'k + d + /', category: 'liquids' },
  { char: 'ത്യ', name: 'ത്യ (ത + യ)', formula: 'ത (l) + ് (d) + യ (/)', keys: 'l + d + /', category: 'liquids' },
  { char: 'ദ്യ', name: 'ദ്യ (ദ + യ)', formula: 'ദ (o) + ് (d) + യ (/)', keys: 'o + d + /', category: 'liquids' },
  { char: 'പ്യ', name: 'പ്യ (പ + യ)', formula: 'പ (h) + ് (d) + യ (/)', keys: 'h + d + /', category: 'liquids' },
  { char: 'മ്യ', name: 'മ്യ (മ + യ)', formula: 'മ (c) + ് (d) + യ (/)', keys: 'c + d + /', category: 'liquids' },
  { char: 'ശ്യ', name: 'ശ്യ (ശ + യ)', formula: 'ശ (M) + ് (d) + യ (/)', keys: 'M + d + /', category: 'liquids' },

  // Consonants with V (വ / ്വ - Va conjuncts)
  { char: 'ത്വ', name: 'ത്വ (ത + വ)', formula: 'ത (l) + ് (d) + വ (b)', keys: 'l + d + b', category: 'liquids' },
  { char: 'ദ്വ', name: 'ദ്വ (ദ + വ)', formula: 'ദ (o) + ് (d) + വ (b)', keys: 'o + d + b', category: 'liquids' },
  { char: 'സ്വ', name: 'സ്വ (സ + വ)', formula: 'സ (m) + ് (d) + വ (b)', keys: 'm + d + b', category: 'liquids' },
];

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'conjuncts' | 'chillu' | 'vowels' | 'principles' | 'shortcuts'>('conjuncts');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedChar, setCopiedChar] = useState<string | null>(null);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedChar(text);
    setTimeout(() => setCopiedChar(null), 1500);
  };

  const filteredConjuncts = useMemo(() => {
    if (!searchQuery.trim()) return CONJUNCTS_DATA;
    const q = searchQuery.toLowerCase().trim();
    return CONJUNCTS_DATA.filter(
      (c) =>
        c.char.includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.formula.toLowerCase().includes(q) ||
        c.keys.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl max-w-3xl w-full flex flex-col overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 px-6 border-b border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-red-500 text-white flex items-center justify-center shadow-sm shadow-rose-500/20 font-serif font-bold text-base">
              അ
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>Inscript Typing Guide &amp; Shortcuts</span>
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                മലയാളം ഇൻസ്ക്രിപ്റ്റ് സമഗ്ര ടൈപ്പിംഗ് സഹായിയും കീബോർഡ് ഷോർട്ട്കട്ടുകളും
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 sm:gap-2 px-4 sm:px-6 pt-2 border-b border-stone-100 dark:border-stone-800 text-xs font-medium overflow-x-auto no-scrollbar">
          {[
            { id: 'conjuncts', label: 'കൂട്ടക്ഷരങ്ങൾ (Conjuncts)', count: CONJUNCTS_DATA.length },
            { id: 'chillu', label: 'ചില്ലക്ഷരങ്ങൾ (Chillu)', count: 6 },
            { id: 'vowels', label: 'സ്വരങ്ങളും ചിഹ്നങ്ങളും (Vowels)', count: 28 },
            { id: 'principles', label: 'തത്വങ്ങൾ (Layout Map)', count: null },
            { id: 'shortcuts', label: 'ഷോർട്ട്കട്ടുകൾ (Shortcuts)', count: 14 },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setSearchQuery('');
              }}
              className={`pb-2.5 px-3 border-b-2 whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'border-rose-600 text-rose-600 dark:text-rose-400 font-semibold'
                  : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== null && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  activeTab === tab.id 
                    ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300' 
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-500'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Search Bar for Conjuncts/Vowels */}
        {(activeTab === 'conjuncts' || activeTab === 'vowels') && (
          <div className="px-6 py-2.5 bg-stone-50 dark:bg-stone-800/40 border-b border-stone-100 dark:border-stone-800 flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Malayalam letter, keys, or combination (e.g., ക്ഷ, k+d, പ്ര, chillu)..."
              className="w-full bg-transparent text-xs text-stone-800 dark:text-stone-200 placeholder:text-stone-400 outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-stone-400 hover:text-stone-600 text-[11px]"
              >
                Clear
              </button>
            )}
          </div>
        )}

        {/* Tab Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs text-stone-700 dark:text-stone-300 flex-1">
          {/* 1. CONJUNCTS TAB */}
          {activeTab === 'conjuncts' && (
            <div className="space-y-3">
              <div className="p-3 bg-rose-50/60 dark:bg-rose-950/30 rounded-xl border border-rose-100 dark:border-rose-900/40 flex items-start gap-2.5">
                <Lightbulb className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                <div className="text-stone-700 dark:text-stone-300">
                  <span className="font-semibold text-stone-900 dark:text-stone-100">
                    കൂട്ടക്ഷരങ്ങൾ ടൈപ്പ് ചെയ്യുന്നതിന്റെ സുവർണ്ണ നിയമം (Golden Rule):
                  </span>
                  <p className="mt-0.5 text-[11px] text-stone-600 dark:text-stone-400 leading-relaxed">
                    <span className="font-bold text-rose-600 dark:text-rose-400">ആദ്യ വ്യഞ്ജനം</span> +{' '}
                    <span className="font-bold font-mono px-1 py-0.2 bg-white dark:bg-stone-800 rounded border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-stone-100">
                      ചന്ദ്രക്കല (D key)
                    </span>{' '}
                    + <span className="font-bold text-rose-600 dark:text-rose-400">രണ്ടാമത്തെ വ്യഞ്ജനം</span>.
                    ഏതൊരു കൂട്ടക്ഷരത്തിലും ക്ലിക്ക് ചെയ്താൽ അത് ഉടനടി ക്ലിപ്പ്ബോർഡിലേക്ക് കോപ്പി ചെയ്യാം!
                  </p>
                </div>
              </div>

              {filteredConjuncts.length === 0 ? (
                <div className="text-center py-8 text-stone-400">
                  No conjunct found matching "{searchQuery}". Try searching by letter or key name.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                  {filteredConjuncts.map((item, idx) => (
                    <div
                      key={idx}
                      onClick={() => handleCopy(item.char)}
                      className="group p-3 rounded-xl border border-stone-200 dark:border-stone-700/80 bg-white dark:bg-stone-800/90 hover:border-rose-300 dark:hover:border-rose-700 hover:shadow-sm cursor-pointer transition-all flex flex-col justify-between relative"
                      title="Click to copy character"
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-2xl font-bold font-noto-sans text-rose-600 dark:text-rose-400">
                          {item.char}
                        </span>
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-stone-400 hover:text-rose-600">
                          {copiedChar === item.char ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </div>
                      </div>
                      <div className="mt-1">
                        <span className="text-[11px] font-medium text-stone-700 dark:text-stone-300 block">
                          {item.name}
                        </span>
                        <span className="text-[10px] text-stone-500 dark:text-stone-400 block truncate mt-0.5">
                          {item.formula}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-[10px] font-mono bg-stone-100 dark:bg-stone-900 px-1.5 py-0.5 rounded border border-stone-200/60 dark:border-stone-800 text-stone-700 dark:text-stone-300 font-semibold">
                          {item.keys}
                        </span>
                        {copiedChar === item.char && (
                          <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-semibold">
                            Copied!
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 2. CHILLU TAB */}
          {activeTab === 'chillu' && (
            <div className="space-y-4">
              <div className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700">
                <span className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-rose-500" />
                  ചില്ലക്ഷരങ്ങൾ (Pure Chillu Letters):
                </span>
                <p className="mt-1 text-stone-500 dark:text-stone-400 text-[11px] leading-relaxed">
                  മലയാളത്തിൽ സ്വരസഹായമില്ലാതെ ഉച്ചരിക്കുന്ന വ്യഞ്ജനങ്ങളാണ് ചില്ലുകൾ (ർ, ൽ, ൾ, ൺ, ൻ, ൿ).
                  യൂണികോഡ് അനുസരിച്ച് ഇവ രണ്ട് രീതിയിൽ ടൈപ്പ് ചെയ്യാം: നേരിട്ടുള്ള ഇൻസ്ക്രിപ്റ്റ് 2 കീ വഴിയോ, അല്ലെങ്കിൽ 
                  വ്യഞ്ജനം + ചന്ദ്രക്കല (D) + ZWJ (Zero Width Joiner) വഴിയോ.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  {
                    char: 'ൻ',
                    title: 'ൻ (ന-യുടെ ചില്ല്)',
                    inscriptKey: 'Shift + v (V) or AltGr + v',
                    zwjFormula: 'ന (v) + ് (d) + ZWJ',
                    examples: 'ഞാൻ, അവൻ, രാജൻ, മനുഷ്യൻ',
                  },
                  {
                    char: 'ർ',
                    title: 'ർ (ര-യുടെ ചില്ല് / റേഫം)',
                    inscriptKey: 'Shift + j (J) or AltGr + j',
                    zwjFormula: 'ര (j) + ് (d) + ZWJ',
                    examples: 'സൂര്യൻ, വാർത്ത, കാർ, ഡോക്ടർ',
                  },
                  {
                    char: 'ൽ',
                    title: 'ൽ (ല-യുടെ ചില്ല്)',
                    inscriptKey: 'Shift + n (N) or AltGr + n',
                    zwjFormula: 'ല (n) + ് (d) + ZWJ',
                    examples: 'പാൽ, കാൽ, കൽക്കണ്ടം, പുൽക്കൂട്',
                  },
                  {
                    char: 'ൾ',
                    title: 'ൾ (ള-യുടെ ചില്ല്)',
                    inscriptKey: 'Shift + > (>) or AltGr + l',
                    zwjFormula: 'ള (N) + ് (d) + ZWJ',
                    examples: 'അവൾ, പൂക്കൾ, കേരളം, ആൾ',
                  },
                  {
                    char: 'ൺ',
                    title: 'ൺ (ണ-യുടെ ചില്ല്)',
                    inscriptKey: 'Shift + c (C) or AltGr + c',
                    zwjFormula: 'ണ (C) + ് (d) + ZWJ',
                    examples: 'കൺകോൺ, കണ്ണ്, ആൺ, പെൺ',
                  },
                  {
                    char: 'ൿ',
                    title: 'ൿ (ക-യുടെ ചില്ല്)',
                    inscriptKey: 'AltGr + k',
                    zwjFormula: 'ക (k) + ് (d) + ZWJ',
                    examples: 'പൊന്മക്, ദൃൿസാക്ഷി, വക്',
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleCopy(item.char)}
                    className="p-4 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 hover:border-rose-300 dark:hover:border-rose-700 cursor-pointer transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-3xl font-bold font-noto-sans text-rose-600 dark:text-rose-400">
                          {item.char}
                        </span>
                        <div className="text-stone-400 hover:text-rose-600">
                          {copiedChar === item.char ? (
                            <Check className="w-4 h-4 text-emerald-500" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </div>
                      </div>
                      <h4 className="font-bold text-stone-900 dark:text-stone-100 text-xs mt-1">
                        {item.title}
                      </h4>
                      <div className="mt-2 space-y-1 text-[11px]">
                        <div className="text-stone-600 dark:text-stone-400">
                          <span className="text-stone-400">Direct Key:</span>{' '}
                          <code className="font-mono px-1 py-0.2 bg-stone-100 dark:bg-stone-900 rounded font-semibold text-rose-600 dark:text-rose-400">
                            {item.inscriptKey}
                          </code>
                        </div>
                        <div className="text-stone-500 dark:text-stone-400">
                          <span className="text-stone-400">ZWJ:</span>{' '}
                          <code className="font-mono text-[10px]">{item.zwjFormula}</code>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-stone-100 dark:border-stone-700/60 text-[10px] text-stone-500 dark:text-stone-400">
                      <span className="font-semibold text-stone-700 dark:text-stone-300">ഉദാഹരണങ്ങൾ:</span> {item.examples}
                    </div>
                  </div>
                ))}
              </div>

              {/* ZWJ Explainer Box */}
              <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200 dark:border-stone-700 text-[11px] space-y-1.5">
                <div className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-rose-500" />
                  ZWJ (Zero Width Joiner) &amp; ZWNJ (Zero Width Non-Joiner):
                </div>
                <p className="text-stone-600 dark:text-stone-400">
                  കൂട്ടക്ഷരങ്ങൾ രൂപപ്പെടുന്നത് തടയാനും ചില്ലക്ഷരങ്ങൾ കൃത്യമായി വേർതിരിക്കാനും യൂണികോഡ് കൺട്രോൾ കാരക്ടറുകൾ ഉപയോഗിക്കാം.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <div className="p-2 bg-white dark:bg-stone-800 rounded-lg border border-stone-200 dark:border-stone-700">
                    <span className="font-mono font-bold text-rose-600">ZWJ (U+200D):</span>
                    <p className="text-[10px] text-stone-500 mt-0.5">ചില്ലക്ഷര രൂപം നിർബന്ധമാക്കുന്നു (ഉദാ: ന + ് + ZWJ = ൻ)</p>
                  </div>
                  <div className="p-2 bg-white dark:bg-stone-800 rounded-lg border border-stone-200 dark:border-stone-700">
                    <span className="font-mono font-bold text-rose-600">ZWNJ (U+200C):</span>
                    <p className="text-[10px] text-stone-500 mt-0.5">കൂട്ടക്ഷരം ചേരാതെ ചന്ദ്രക്കല നിലനിർത്തുന്നു (ഉദാ: പ്‌ + പ)</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 3. VOWELS & MATRAS TAB */}
          {activeTab === 'vowels' && (
            <div className="space-y-4">
              <div className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700">
                <span className="font-semibold text-stone-900 dark:text-stone-100">
                  സ്വതന്ത്ര സ്വരങ്ങളും സ്വരചിഹ്നങ്ങളും (Independent Vowels &amp; Matras):
                </span>
                <p className="mt-1 text-stone-500 dark:text-stone-400 text-[11px]">
                  വാക്കിന്റെ തുടക്കത്തിൽ സ്വതന്ത്ര സ്വരം (Vowel) ടൈപ്പ് ചെയ്യുക. വ്യഞ്ജനത്തോടൊപ്പം ചിഹ്നമായി ചേർക്കാൻ മാത്രാ കീ (Matra) ടൈപ്പ് ചെയ്യുക.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {[
                  { vowel: 'അ', matra: '-', name: 'അ', vKey: 'Shift + d (D)', mKey: 'സ്വാഭാവികം' },
                  { vowel: 'ആ', matra: 'ാ (കാ)', name: 'ആ / ദീർഘം', vKey: 'Shift + e (E)', mKey: 'e' },
                  { vowel: 'ഇ', matra: 'ി (കി)', name: 'ഇ / വള്ളി', vKey: 'Shift + f (F)', mKey: 'f' },
                  { vowel: 'ഈ', matra: 'ീ (കീ)', name: 'ഈ / ദീർഘവള്ളി', vKey: 'Shift + r (R)', mKey: 'r' },
                  { vowel: 'ഉ', matra: 'ു (കു)', name: 'ഉ', vKey: 'Shift + g (G)', mKey: 'g' },
                  { vowel: 'ഊ', matra: 'ൂ (കൂ)', name: 'ഊ', vKey: 'Shift + t (T)', mKey: 't' },
                  { vowel: 'ഋ', matra: 'ൃ (കൃ)', name: 'ഋ', vKey: 'Shift + + (+)', mKey: '=' },
                  { vowel: 'എ', matra: 'െ (കെ)', name: 'എ', vKey: 'Shift + s (S)', mKey: 's' },
                  { vowel: 'ഏ', matra: 'േ (കേ)', name: 'ഏ', vKey: 'Shift + w (W)', mKey: 'w' },
                  { vowel: 'ഐ', matra: 'ൈ (കൈ)', name: 'ഐ', vKey: 'Shift + q (Q)', mKey: 'q' },
                  { vowel: 'ഒ', matra: 'ൊ (കൊ)', name: 'ഒ', vKey: 'Shift + a (A)', mKey: 'a' },
                  { vowel: 'ഓ', matra: 'ോ (കോ)', name: 'ഓ', vKey: 'Shift + S (K)', mKey: 'Shift + a (A)' },
                  { vowel: 'ഔ', matra: 'ൌ (കൗ)', name: 'ഔ', vKey: 'Shift + % (%)', mKey: 'Shift + q (Q)' },
                  { vowel: 'ം', matra: 'ം (കം)', name: 'അനുസ്വാരം', vKey: 'x', mKey: 'x' },
                  { vowel: 'ഃ', matra: 'ഃ (കഃ)', name: 'വിസർഗ്ഗം', vKey: 'Shift + _ (_)', mKey: 'Shift + _' },
                  { vowel: '്', matra: '് (ക്)', name: 'ചന്ദ്രക്കല', vKey: 'd', mKey: 'd' },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleCopy(item.vowel !== '-' ? item.vowel : '')}
                    className="p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 hover:border-rose-300 dark:hover:border-rose-700 cursor-pointer transition-all flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold font-noto-sans text-rose-600 dark:text-rose-400">
                        {item.vowel}
                      </span>
                      <span className="text-sm font-semibold text-stone-600 dark:text-stone-300">
                        {item.matra}
                      </span>
                    </div>
                    <div className="mt-1">
                      <span className="text-[11px] font-medium text-stone-800 dark:text-stone-200 block truncate">
                        {item.name}
                      </span>
                      <div className="mt-1 flex flex-col gap-0.5 text-[9px] text-stone-500 dark:text-stone-400 font-mono">
                        <span>Vowel: {item.vKey}</span>
                        <span>Matra: {item.mKey}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. PRINCIPLES & LAYOUT TAB */}
          {activeTab === 'principles' && (
            <div className="space-y-4">
              <div className="p-4 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700 space-y-2">
                <h4 className="font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-rose-600" />
                  ഇൻസ്ക്രിപ്റ്റ് ലേഔട്ടിന്റെ അടിസ്ഥാന ക്രമീകരണം (Inscript Logic)
                </h4>
                <p className="text-[11px] text-stone-600 dark:text-stone-300 leading-relaxed">
                  ഇന്ത്യൻ ഭാഷകൾക്ക് വേണ്ടി ഇന്ത്യൻ സർക്കാർ ശാസ്ത്രീയമായി രൂപകൽപ്പന ചെയ്ത കീബോർഡ് മാനദണ്ഡമാണ് <strong>Inscript</strong>.
                  ഇത് പഠിക്കാൻ വളരെ എളുപ്പമാണ്:
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 space-y-2">
                  <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold">
                    <span className="w-6 h-6 rounded-lg bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center text-xs">L</span>
                    ഇടത് കൈ (Left Hand Side): സ്വരങ്ങൾ
                  </div>
                  <p className="text-[11px] text-stone-600 dark:text-stone-400">
                    കീബോർഡിന്റെ ഇടത് ഭാഗം (Q, W, E, R, T, A, S, D, F, G, Z, X, C, V) മുഴുവൻ സ്വരങ്ങൾക്കും (Vowels) സ്വരചിഹ്നങ്ങൾക്കും (Matras) വേണ്ടി നീക്കിവെച്ചിരിക്കുന്നു.
                  </p>
                  <div className="p-2 rounded bg-stone-100 dark:bg-stone-900 font-mono text-[10px] text-stone-700 dark:text-stone-300">
                    D = ചന്ദ്രക്കല (്) / അ | E = ാ / ആ | F = ി / ഇ | S = െ / എ | W = േ / ഏ | A = ൊ / ഒ
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 space-y-2">
                  <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold">
                    <span className="w-6 h-6 rounded-lg bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center text-xs">R</span>
                    വലത് കൈ (Right Hand Side): വ്യഞ്ജനങ്ങൾ
                  </div>
                  <p className="text-[11px] text-stone-600 dark:text-stone-400">
                    കീബോർഡിന്റെ വലത് ഭാഗം (Y, U, I, O, P, H, J, K, L, ;, N, M) മുഴുവൻ വ്യഞ്ജനങ്ങൾ (Consonants) അടങ്ങിയിരിക്കുന്നു.
                  </p>
                  <div className="p-2 rounded bg-stone-100 dark:bg-stone-900 font-mono text-[10px] text-stone-700 dark:text-stone-300">
                    K = ക | I = ഗ | P = ച | ; = ജ | ' = ട | [ = ഡ | L = ത | O = ദ | H = പ | Y = ബ | C = മ | V = ന
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-rose-50/50 dark:bg-rose-950/20 rounded-xl border border-rose-100 dark:border-rose-900/30 text-[11px] space-y-1.5">
                <span className="font-semibold text-rose-700 dark:text-rose-300">
                  Shift കീയുടെ പ്രത്യേകത (Shift Key Logic):
                </span>
                <p className="text-stone-600 dark:text-stone-400">
                  ഒരു വ്യഞ്ജനത്തിന്റെ അല്പപ്രാണ രൂപമാണ് സാധാരണ കീ എങ്കിൽ, അതിന്റെ മഹാപ്രാണ രൂപം (Aspirated form) അതേ കീയുടെ Shift അമർത്തുമ്പോൾ ലഭിക്കും:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[10px] font-mono">
                  <span className="p-1.5 bg-white dark:bg-stone-800 rounded border border-stone-200 dark:border-stone-700">k (ക) → K (ഖ)</span>
                  <span className="p-1.5 bg-white dark:bg-stone-800 rounded border border-stone-200 dark:border-stone-700">i (ഗ) → I (ഘ)</span>
                  <span className="p-1.5 bg-white dark:bg-stone-800 rounded border border-stone-200 dark:border-stone-700">p (ച) → P (ഛ)</span>
                  <span className="p-1.5 bg-white dark:bg-stone-800 rounded border border-stone-200 dark:border-stone-700">l (ത) → L (ഥ)</span>
                </div>
              </div>
            </div>
          )}

          {/* 5. SHORTCUTS TAB */}
          {activeTab === 'shortcuts' && (
            <div className="space-y-4">
              <div className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-amber-500" />
                    പ്രധാന എഡിറ്റർ ഷോർട്ട്കട്ടുകൾ (Keyboard Shortcuts)
                  </span>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400">
                    ടൈപ്പിംഗ് വേഗത വർദ്ധിപ്പിക്കാനും കാര്യക്ഷമമായി എഡിറ്റ് ചെയ്യാനും
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { key: 'Ctrl + S', desc: 'Save document (സ്വമേധയാ സേവ് ചെയ്യുക)', tag: 'Save' },
                  { key: 'Ctrl + N', desc: 'Create a new blank document (പുതിയ പ്രമാണം)', tag: 'New' },
                  { key: 'Ctrl + F', desc: 'Find and Replace in Malayalam/English (കണ്ടെത്തുക)', tag: 'Search' },
                  { key: 'Ctrl + P', desc: 'Print document or Export as PDF (പ്രിന്റ് / പിഡിഎഫ്)', tag: 'Export' },
                  { key: 'Ctrl + Z', desc: 'Undo last editing step (തിരുത്ത് പിൻവലിക്കുക)', tag: 'Edit' },
                  { key: 'Ctrl + Y', desc: 'Redo undone action (വീണ്ടും ചെയ്യുക)', tag: 'Edit' },
                  { key: 'Ctrl + B', desc: 'Format selected text as Bold (ബോൾഡ്)', tag: 'Format' },
                  { key: 'Ctrl + I', desc: 'Format selected text as Italic (ഇറ്റാലിക്)', tag: 'Format' },
                  { key: 'Ctrl + U', desc: 'Underline text (അടിവര)', tag: 'Format' },
                  { key: 'Ctrl + K', desc: 'Toggle Inscript on-screen keyboard (കീബോർഡ് പാനൽ)', tag: 'Keyboard' },
                  { key: 'Ctrl + A', desc: 'Select all content in document (മുഴുവൻ തിരഞ്ഞെടുക്കുക)', tag: 'Select' },
                  { key: 'Alt + 1', desc: 'Switch to Writer tab (എഴുത്ത് പാനൽ)', tag: 'Nav' },
                  { key: 'Alt + 2', desc: 'Switch to Translate tab (വിവർത്തനം)', tag: 'Nav' },
                  { key: 'Alt + 3', desc: 'Switch to Documents tab (ഫയൽ ലൈബ്രറി)', tag: 'Nav' },
                  { key: 'Alt + 4', desc: 'Switch to OCR tab (ചിത്രങ്ങളിൽ നിന്ന് മലയാളം)', tag: 'Nav' },
                  { key: 'Esc', desc: 'Close open dialogs, Find Bar, or modals', tag: 'UI' },
                ].map((sc, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 hover:border-stone-300 dark:hover:border-stone-600 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold px-2 py-1 rounded bg-stone-100 dark:bg-stone-900 text-rose-600 dark:text-rose-400 text-xs border border-stone-200/60 dark:border-stone-800 shrink-0">
                        {sc.key}
                      </span>
                      <span className="text-xs text-stone-700 dark:text-stone-300 font-medium">
                        {sc.desc}
                      </span>
                    </div>
                    <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-stone-100 dark:bg-stone-800 text-stone-500 font-semibold shrink-0">
                      {sc.tag}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 px-6 bg-stone-50/80 dark:bg-stone-900/80 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
          <div className="text-[11px] text-stone-500 dark:text-stone-400 hidden sm:block">
            Tip: Press <kbd className="font-mono px-1.5 py-0.5 rounded bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300">Esc</kbd> anytime to close this guide
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white text-xs font-semibold shadow-sm transition-all"
          >
            Close Guide (പൂർത്തിയാക്കുക)
          </button>
        </div>
      </div>
    </div>
  );
};

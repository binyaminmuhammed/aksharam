import React, { useState, useRef, useEffect } from 'react';
import { 
  PenTool, 
  Languages, 
  Files, 
  ScanLine, 
  Keyboard as KeyboardIcon, 
  Sun, 
  Moon, 
  Monitor, 
  Check,
  Settings, 
  HelpCircle 
} from 'lucide-react';
import { ThemeMode } from '../../types';

interface AppHeaderProps {
  activeTab: 'writer' | 'translate' | 'documents' | 'ocr';
  setActiveTab: (tab: 'writer' | 'translate' | 'documents' | 'ocr') => void;
  showKeyboard: boolean;
  setShowKeyboard: (val: boolean) => void;
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  openSettings: () => void;
  openHelp: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  activeTab,
  setActiveTab,
  showKeyboard,
  setShowKeyboard,
  theme,
  setTheme,
  openSettings,
  openHelp,
}) => {
  const [themeMenuOpen, setThemeMenuOpen] = useState(false);
  const themeMenuRef = useRef<HTMLDivElement>(null);

  // Detect current system preference for display in menu
  const [isSystemDark, setIsSystemDark] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      setIsSystemDark(media.matches);
      const listener = (e: MediaQueryListEvent) => setIsSystemDark(e.matches);
      if (media.addEventListener) {
        media.addEventListener('change', listener);
        return () => media.removeEventListener('change', listener);
      }
    }
  }, []);

  // Close dropdown on outside click or Escape key
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (themeMenuRef.current && !themeMenuRef.current.contains(e.target as Node)) {
        setThemeMenuOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setThemeMenuOpen(false);
    };

    if (themeMenuOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [themeMenuOpen]);

  const selectTheme = (mode: ThemeMode) => {
    setTheme(mode);
    setThemeMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur border-b border-stone-200/80 dark:border-stone-800 transition-colors no-print">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Left: Branding */}
        <div 
          onClick={() => setActiveTab('writer')}
          className="flex items-center gap-2.5 cursor-pointer select-none group"
        >
          <div className="w-10 h-10 rounded-xl overflow-hidden shadow-sm shadow-rose-500/20 group-hover:scale-105 transition-transform shrink-0 border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-stone-800 flex items-center justify-center">
            <img 
              src="/logo.png" 
              alt="Aksharam Logo" 
              className="w-full h-full object-cover"
              onError={(e) => {
                const target = e.currentTarget;
                target.style.display = 'none';
                if (target.parentElement) {
                  target.parentElement.innerHTML = '<span class="font-bold text-lg font-serif text-rose-600">അ</span>';
                }
              }}
            />
          </div>
          <div className="hidden xs:block sm:block">
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-stone-900 dark:text-stone-100 text-base sm:text-lg tracking-tight flex items-center gap-1.5">
                <span>Aksharam</span>
                <span className="font-serif text-rose-600 dark:text-rose-400 font-semibold text-sm">അക്ഷരം</span>
              </h1>
              <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400">
                Inscript
              </span>
            </div>
            <p className="text-xs text-stone-500 dark:text-stone-400 hidden sm:block">
              Malayalam Typing &amp; Document Editor
            </p>
          </div>
        </div>

        {/* Center: Primary Navigation */}
        <nav className="flex items-center p-1 bg-stone-100 dark:bg-stone-800/80 rounded-xl border border-stone-200/60 dark:border-stone-700/60 text-xs sm:text-sm font-medium">
          <button
            onClick={() => setActiveTab('writer')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'writer'
                ? 'bg-white dark:bg-stone-900 text-rose-600 dark:text-rose-400 shadow-xs font-semibold'
                : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>Writer</span>
          </button>

          <button
            onClick={() => setActiveTab('translate')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'translate'
                ? 'bg-white dark:bg-stone-900 text-rose-600 dark:text-rose-400 shadow-xs font-semibold'
                : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <Languages className="w-3.5 h-3.5" />
            <span>Translate</span>
          </button>

          <button
            onClick={() => setActiveTab('documents')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'documents'
                ? 'bg-white dark:bg-stone-900 text-rose-600 dark:text-rose-400 shadow-xs font-semibold'
                : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <Files className="w-3.5 h-3.5" />
            <span>Documents</span>
          </button>

          <button
            onClick={() => setActiveTab('ocr')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'ocr'
                ? 'bg-white dark:bg-stone-900 text-rose-600 dark:text-rose-400 shadow-xs font-semibold'
                : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            <ScanLine className="w-3.5 h-3.5" />
            <span className="hidden md:inline">PDF/Image</span> OCR
          </button>
        </nav>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* On-screen Keyboard Toggle (quick switch) */}
          <button
            onClick={() => setShowKeyboard(!showKeyboard)}
            title={showKeyboard ? 'Hide On-screen Keyboard' : 'Show On-screen Keyboard'}
            aria-label="Toggle Keyboard"
            className={`p-2 rounded-lg border transition-all ${
              showKeyboard
                ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/60'
                : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-700/60'
            }`}
          >
            <KeyboardIcon className="w-4 h-4" />
          </button>

          {/* Theme Selector Dropdown */}
          <div className="relative" ref={themeMenuRef}>
            <button
              onClick={() => setThemeMenuOpen(!themeMenuOpen)}
              title={`Theme: ${theme}. Click to switch theme`}
              aria-label="Select Theme"
              aria-haspopup="true"
              aria-expanded={themeMenuOpen}
              className={`p-2 rounded-lg border transition-all flex items-center gap-1 ${
                themeMenuOpen
                  ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-rose-300 dark:border-rose-800'
                  : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-700/60'
              }`}
            >
              {theme === 'light' && <Sun className="w-4 h-4 text-amber-500" />}
              {theme === 'dark' && <Moon className="w-4 h-4 text-sky-400" />}
              {theme === 'system' && (
                <Monitor className="w-4 h-4 text-stone-600 dark:text-stone-300" />
              )}
            </button>

            {themeMenuOpen && (
              <div 
                className="absolute right-0 mt-2 w-48 bg-white dark:bg-stone-800 rounded-xl shadow-xl border border-stone-200 dark:border-stone-700 p-1.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                role="menu"
                aria-label="Theme options"
              >
                <div className="px-2.5 py-1 text-[11px] font-semibold text-stone-400 dark:text-stone-500 uppercase tracking-wider">
                  Theme Appearance
                </div>

                <button
                  type="button"
                  onClick={() => selectTheme('light')}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-colors text-left ${
                    theme === 'light'
                      ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 font-semibold'
                      : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700/60'
                  }`}
                  role="menuitem"
                >
                  <div className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-amber-500 shrink-0" />
                    <div>
                      <div>Light</div>
                      <div className="text-[10px] opacity-70 font-normal">ലൈറ്റ് മോഡ്</div>
                    </div>
                  </div>
                  {theme === 'light' && <Check className="w-4 h-4 text-rose-600 dark:text-rose-400" />}
                </button>

                <button
                  type="button"
                  onClick={() => selectTheme('dark')}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-colors text-left ${
                    theme === 'dark'
                      ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 font-semibold'
                      : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700/60'
                  }`}
                  role="menuitem"
                >
                  <div className="flex items-center gap-2">
                    <Moon className="w-4 h-4 text-sky-400 shrink-0" />
                    <div>
                      <div>Dark</div>
                      <div className="text-[10px] opacity-70 font-normal">ഡാർക്ക് മോഡ്</div>
                    </div>
                  </div>
                  {theme === 'dark' && <Check className="w-4 h-4 text-rose-600 dark:text-rose-400" />}
                </button>

                <button
                  type="button"
                  onClick={() => selectTheme('system')}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-colors text-left ${
                    theme === 'system'
                      ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 font-semibold'
                      : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700/60'
                  }`}
                  role="menuitem"
                >
                  <div className="flex items-center gap-2">
                    <Monitor className="w-4 h-4 text-stone-500 shrink-0" />
                    <div>
                      <div className="flex items-center gap-1">
                        <span>System</span>
                        <span className="text-[9px] px-1 py-0.2 rounded bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300 font-normal">
                          {isSystemDark ? 'Dark' : 'Light'}
                        </span>
                      </div>
                      <div className="text-[10px] opacity-70 font-normal">സിസ്റ്റം ഡിഫോൾട്ട്</div>
                    </div>
                  </div>
                  {theme === 'system' && <Check className="w-4 h-4 text-rose-600 dark:text-rose-400" />}
                </button>
              </div>
            )}
          </div>

          {/* Help button */}
          <button
            onClick={openHelp}
            title="Inscript Keyboard Guide & Shortcuts"
            aria-label="Help Guide"
            className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-700/60 transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Settings button */}
          <button
            onClick={openSettings}
            title="Preferences & Typography Settings"
            aria-label="Settings"
            className="p-2 rounded-lg bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-700/60 transition-colors"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

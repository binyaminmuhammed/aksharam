import React, { useState, useEffect } from 'react';
import { Check, Clock, Edit2 } from 'lucide-react';

interface DocumentHeaderProps {
  title: string;
  onTitleChange: (newTitle: string) => void;
  isSaving: boolean;
  lastSaved: Date | null;
}

export const DocumentHeader: React.FC<DocumentHeaderProps> = ({
  title,
  onTitleChange,
  isSaving,
  lastSaved,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempTitle, setTempTitle] = useState(title);
  const [relativeTime, setRelativeTime] = useState<string>('just now');

  useEffect(() => {
    setTempTitle(title);
  }, [title]);

  useEffect(() => {
    if (!lastSaved) return;

    const updateTime = () => {
      const diffSecs = Math.floor((Date.now() - lastSaved.getTime()) / 1000);
      if (diffSecs < 5) setRelativeTime('just now');
      else if (diffSecs < 60) setRelativeTime(`${diffSecs}s ago`);
      else setRelativeTime(`${Math.floor(diffSecs / 60)}m ago`);
    };

    updateTime();
    const interval = setInterval(updateTime, 5000);
    return () => clearInterval(interval);
  }, [lastSaved]);

  const handleSubmit = () => {
    const finalTitle = tempTitle.trim() || 'Untitled Malayalam Document';
    onTitleChange(finalTitle);
    setIsEditing(false);
  };

  return (
    <div className="flex items-center justify-between gap-4 py-2 px-1 text-sm no-print">
      {/* Document Title Editable */}
      <div className="flex items-center gap-2 max-w-[70%]">
        {isEditing ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSubmit();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              autoFocus
              value={tempTitle}
              onChange={(e) => setTempTitle(e.target.value)}
              onBlur={handleSubmit}
              className="px-2.5 py-1 text-base font-semibold bg-white dark:bg-stone-800 border border-rose-300 dark:border-rose-700 rounded-lg text-stone-900 dark:text-stone-100 outline-none ring-2 ring-rose-500/20"
            />
          </form>
        ) : (
          <div
            onClick={() => setIsEditing(true)}
            className="group flex items-center gap-2 cursor-pointer select-none py-1 px-2 -ml-2 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800/60 transition-colors"
          >
            <h2 className="text-base sm:text-lg font-semibold text-stone-900 dark:text-stone-100 truncate">
              {title}
            </h2>
            <Edit2 className="w-3.5 h-3.5 text-stone-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        )}
      </div>

      {/* Autosave Status Indicator */}
      <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 select-none">
        {isSaving ? (
          <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span>Saving...</span>
          </div>
        ) : lastSaved ? (
          <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
            <Check className="w-3.5 h-3.5" />
            <span>Saved {relativeTime}</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-stone-400">
            <Clock className="w-3.5 h-3.5" />
            <span>Not saved yet</span>
          </div>
        )}
      </div>
    </div>
  );
};

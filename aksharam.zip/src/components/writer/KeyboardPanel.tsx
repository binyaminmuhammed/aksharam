import React, { useState } from 'react';
import { KeyboardLayoutType, KeyDefinition } from '../../types';
import { keyboardLayouts, layoutLabels } from '../../lib/keyboardLayouts';
import { playKeyClickSound } from '../../services/keyboardService';
import { X, Volume2, VolumeX, CornerDownLeft, Delete } from 'lucide-react';

interface KeyboardPanelProps {
  currentLayout: KeyboardLayoutType;
  onLayoutChange: (layout: KeyboardLayoutType) => void;
  onKeyPress: (char: string) => void;
  onBackspace: () => void;
  onEnter: () => void;
  onClose: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const KeyboardPanel: React.FC<KeyboardPanelProps> = ({
  currentLayout,
  onLayoutChange,
  onKeyPress,
  onBackspace,
  onEnter,
  onClose,
  soundEnabled,
  onToggleSound,
}) => {
  const [isShiftActive, setIsShiftActive] = useState(false);
  const [isCapsActive, setIsCapsActive] = useState(false);

  const rows = keyboardLayouts[currentLayout] || keyboardLayouts.inscript;

  const handleKeyClick = (key: KeyDefinition) => {
    if (soundEnabled) {
      playKeyClickSound();
    }

    if (key.code === 'ShiftLeft' || key.code === 'ShiftRight') {
      setIsShiftActive((prev) => !prev);
      return;
    }

    if (key.code === 'CapsLock') {
      setIsCapsActive((prev) => !prev);
      return;
    }

    if (key.code === 'Backspace') {
      onBackspace();
      return;
    }

    if (key.code === 'Enter') {
      onEnter();
      return;
    }

    if (key.code === 'Tab') {
      onKeyPress('\t');
      return;
    }

    if (key.code === 'Space') {
      onKeyPress(' ');
      return;
    }

    if (key.isSpecial) {
      return;
    }

    const useShift = isShiftActive || isCapsActive;
    const char = useShift && key.shift ? key.shift : key.normal;

    if (char) {
      onKeyPress(char);
    }

    // Single-use shift release like normal keyboards
    if (isShiftActive && !isCapsActive) {
      setIsShiftActive(false);
    }
  };

  return (
    <div className="onscreen-keyboard bg-stone-100 dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 p-2 sm:p-3 shadow-inner select-none no-print transition-all">
      {/* Keyboard Header bar */}
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-2 pb-2 mb-1 border-b border-stone-200/70 dark:border-stone-800 text-xs">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-stone-700 dark:text-stone-300">
            On-Screen Keyboard:
          </span>

          {/* Layout radio buttons / selector */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {(['inscript', 'gist', 'typewriter', 'panchari', 'varityper', 'english'] as KeyboardLayoutType[]).map((layout) => (
              <button
                key={layout}
                onClick={() => onLayoutChange(layout)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  currentLayout === layout
                    ? 'bg-rose-600 text-white shadow-2xs font-semibold'
                    : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-700'
                }`}
              >
                {layoutLabels[layout]}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute Keyboard Click' : 'Enable Keyboard Click'}
            className="p-1 rounded text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-rose-500" /> : <VolumeX className="w-4 h-4 text-stone-400" />}
          </button>

          {/* Close keyboard */}
          <button
            onClick={onClose}
            title="Hide on-screen keyboard"
            className="p-1 rounded text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Keyboard Grid */}
      <div className="max-w-5xl mx-auto flex flex-col gap-1.5 pt-1 overflow-x-auto pb-1">
        {rows.map((row, rowIndex) => (
          <div key={rowIndex} className="flex gap-1 justify-center w-full min-w-[760px]">
            {row.keys.map((key) => {
              const useShift = isShiftActive || isCapsActive;
              const primaryChar = useShift && key.shift ? key.shift : key.normal;
              const isModifierActive = 
                (key.code === 'ShiftLeft' || key.code === 'ShiftRight') && isShiftActive ||
                key.code === 'CapsLock' && isCapsActive;

              return (
                <button
                  key={key.code}
                  type="button"
                  onClick={() => handleKeyClick(key)}
                  className={`
                    relative group flex flex-col items-center justify-center rounded-lg border transition-all active:scale-95 select-none
                    h-10 sm:h-12 text-xs font-medium shadow-2xs
                    ${key.width ? key.width : 'flex-1 min-w-[36px] sm:min-w-[44px]'}
                    ${isModifierActive 
                      ? 'bg-rose-500 border-rose-600 text-white font-bold shadow-xs ring-2 ring-rose-400/40' 
                      : key.isSpecial
                      ? 'bg-stone-200/80 dark:bg-stone-800 border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-300 dark:hover:bg-stone-700'
                      : 'bg-white dark:bg-stone-800/90 border-stone-200 dark:border-stone-700 hover:border-rose-300 dark:hover:border-rose-700 hover:bg-rose-50/40 dark:hover:bg-rose-950/20 text-stone-900 dark:text-stone-100'}
                  `}
                >
                  {/* English physical key label indicator */}
                  {key.label && (
                    <span className="text-[10px] text-stone-400 dark:text-stone-500 leading-none">
                      {key.label}
                    </span>
                  )}

                  {/* Malayalam mapped character or special icon */}
                  {key.code === 'Backspace' ? (
                    <Delete className="w-4 h-4" />
                  ) : key.code === 'Enter' ? (
                    <div className="flex items-center gap-1 font-bold">
                      <span>ENTER</span>
                      <CornerDownLeft className="w-3.5 h-3.5" />
                    </div>
                  ) : (
                    <span className={`text-base sm:text-lg leading-none mt-0.5 font-noto-sans ${useShift ? 'text-rose-600 dark:text-rose-400 font-semibold' : ''}`}>
                      {primaryChar}
                    </span>
                  )}

                  {/* Sub-label for unshifted character when shifted */}
                  {key.shift && !key.isSpecial && (
                    <span className="text-[9px] text-stone-400 dark:text-stone-500 absolute bottom-0.5 right-1 opacity-60">
                      {useShift ? key.normal : key.shift}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

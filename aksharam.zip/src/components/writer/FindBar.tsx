import React, { useState } from 'react';
import { Search, ChevronUp, ChevronDown, X, Replace } from 'lucide-react';

interface FindBarProps {
  isOpen: boolean;
  onClose: () => void;
  onFind: (query: string, direction: 'next' | 'prev') => void;
  onReplace: (query: string, replacement: string, replaceAll: boolean) => void;
  matchIndex: number;
  totalMatches: number;
}

export const FindBar: React.FC<FindBarProps> = ({
  isOpen,
  onClose,
  onFind,
  onReplace,
  matchIndex,
  totalMatches,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');
  const [showReplace, setShowReplace] = useState(false);

  if (!isOpen) return null;

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (val) {
      onFind(val, 'next');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      onFind(searchQuery, e.shiftKey ? 'prev' : 'next');
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div className="bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl shadow-lg p-2 mb-2 animate-in fade-in slide-in-from-top-2 duration-150 no-print">
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-1.5 px-2 py-1 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg flex-1 min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-stone-400" />
          <input
            type="text"
            autoFocus
            placeholder="കണ്ടെത്തുക / Find in Malayalam or English..."
            value={searchQuery}
            onChange={handleSearchChange}
            onKeyDown={handleKeyDown}
            className="w-full bg-transparent text-xs text-stone-900 dark:text-stone-100 outline-none"
          />
          {searchQuery && (
            <span className="text-[11px] text-stone-400 whitespace-nowrap px-1">
              {totalMatches > 0 ? `${matchIndex + 1} of ${totalMatches}` : 'No matches'}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => onFind(searchQuery, 'prev')}
            disabled={totalMatches === 0}
            title="Previous match (Shift + Enter)"
            className="p-1.5 rounded-lg text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 disabled:opacity-40"
          >
            <ChevronUp className="w-4 h-4" />
          </button>

          <button
            onClick={() => onFind(searchQuery, 'next')}
            disabled={totalMatches === 0}
            title="Next match (Enter)"
            className="p-1.5 rounded-lg text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 disabled:opacity-40"
          >
            <ChevronDown className="w-4 h-4" />
          </button>

          <button
            onClick={() => setShowReplace(!showReplace)}
            title="Toggle Replace"
            className={`p-1.5 rounded-lg transition-colors ${
              showReplace
                ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700'
            }`}
          >
            <Replace className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            title="Close (Esc)"
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showReplace && (
        <div className="flex items-center gap-2 mt-2 pt-2 border-t border-stone-100 dark:border-stone-700/60 flex-wrap">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg flex-1 min-w-[200px]">
            <input
              type="text"
              placeholder="മാറ്റിസ്ഥാപിക്കുക / Replace with..."
              value={replaceQuery}
              onChange={(e) => setReplaceQuery(e.target.value)}
              className="w-full bg-transparent text-xs text-stone-900 dark:text-stone-100 outline-none"
            />
          </div>

          <button
            onClick={() => onReplace(searchQuery, replaceQuery, false)}
            disabled={!searchQuery || totalMatches === 0}
            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-stone-100 dark:bg-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-600 disabled:opacity-40 transition-colors"
          >
            Replace
          </button>

          <button
            onClick={() => onReplace(searchQuery, replaceQuery, true)}
            disabled={!searchQuery || totalMatches === 0}
            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-rose-600 text-white hover:bg-rose-700 disabled:opacity-40 transition-colors"
          >
            Replace All
          </button>
        </div>
      )}
    </div>
  );
};

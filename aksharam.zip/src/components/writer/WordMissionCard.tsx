import React, { useState } from 'react';
import {
  Target,
  Trophy,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Plus,
  Minus,
  Edit2,
  Check,
  RotateCcw,
  BookOpen,
} from 'lucide-react';

interface WordMissionCardProps {
  currentWordCount: number;
  wordGoal: number;
  missionTitle: string;
  onUpdateGoal: (newGoal: number) => void;
  onUpdateTitle: (newTitle: string) => void;
  onClose?: () => void;
}

const PRESET_GOALS = [
  { label: 'കുറിപ്പ് (Note)', words: 100 },
  { label: 'ലഘുലേഖനം (Micro)', words: 250 },
  { label: 'ചെറുകഥ (Story)', words: 500 },
  { label: 'ഉപന്യാസം (Essay)', words: 1000 },
  { label: 'സമഗ്ര രചന (Deep Work)', words: 2000 },
];

export const WordMissionCard: React.FC<WordMissionCardProps> = ({
  currentWordCount,
  wordGoal,
  missionTitle,
  onUpdateGoal,
  onUpdateTitle,
  onClose,
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [tempTitle, setTempTitle] = useState(missionTitle);

  const goal = Math.max(10, wordGoal || 500);
  const percentage = Math.min(100, Math.round((currentWordCount / goal) * 100));
  const isAccomplished = currentWordCount >= goal;
  const wordsRemaining = Math.max(0, goal - currentWordCount);
  const wordsExceeded = Math.max(0, currentWordCount - goal);

  // Approximate reading time: 180 words per minute
  const readingTimeMinutes = Math.max(1, Math.ceil(currentWordCount / 180));

  const handleSaveTitle = () => {
    if (tempTitle.trim()) {
      onUpdateTitle(tempTitle.trim());
    }
    setIsEditingTitle(false);
  };

  return (
    <div
      id="word-mission-section"
      className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 sm:p-4 shadow-xs transition-all no-print"
    >
      {/* Header Row */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2.5">
          <div
            className={`p-2 rounded-xl flex items-center justify-center transition-colors ${
              isAccomplished
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400'
                : 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
            }`}
          >
            {isAccomplished ? (
              <Trophy className="w-5 h-5 animate-bounce" />
            ) : (
              <Target className="w-5 h-5" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              {isEditingTitle ? (
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={tempTitle}
                    onChange={(e) => setTempTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSaveTitle();
                      if (e.key === 'Escape') setIsEditingTitle(false);
                    }}
                    className="px-2 py-0.5 text-xs sm:text-sm font-bold rounded-lg border border-rose-400 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 outline-none"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveTitle}
                    className="p-1 rounded-md bg-rose-600 text-white hover:bg-rose-700"
                    title="Save title"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs sm:text-sm font-bold text-stone-900 dark:text-stone-100">
                    {missionTitle || 'എഴുത്ത് ദൗത്യം (Writing Mission)'}
                  </h3>
                  <button
                    onClick={() => {
                      setTempTitle(missionTitle);
                      setIsEditingTitle(true);
                    }}
                    className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-300 p-0.5"
                    title="Edit mission title"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>
              )}

              {/* Status Pill */}
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                  isAccomplished
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                    : percentage > 50
                    ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                    : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                }`}
              >
                {isAccomplished ? (
                  <>
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>ദൗത്യം വിജയിച്ചു! (Accomplished)</span>
                  </>
                ) : (
                  <>
                    <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
                    <span>പുരോഗമിക്കുന്നു ({percentage}%)</span>
                  </>
                )}
              </span>
            </div>

            <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-0.5">
              {isAccomplished
                ? `ലക്ഷ്യം മറികടന്നു! (${currentWordCount} / ${goal} വാക്കുകൾ)`
                : `${wordsRemaining} വാക്കുകൾ കൂടി ലക്ഷ്യത്തിലേക്ക്`}
            </p>
          </div>
        </div>

        {/* Right Action buttons */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <span>{isExpanded ? 'ചുരുക്കുക' : 'വിശദാംശങ്ങൾ'}</span>
            {isExpanded ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-300 p-1 text-xs"
              title="Close mission tracker"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar (Always visible) */}
      <div className="mt-3">
        <div className="flex items-center justify-between text-xs font-mono mb-1 text-stone-600 dark:text-stone-400">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-stone-900 dark:text-stone-100">
              {currentWordCount}
            </span>
            <span>/</span>
            <span>{goal} വാക്കുകൾ</span>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`font-bold ${
                isAccomplished
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {percentage}%
            </span>
            {wordsExceeded > 0 && (
              <span className="text-emerald-600 dark:text-emerald-400 text-[11px] font-sans">
                (+{wordsExceeded})
              </span>
            )}
          </div>
        </div>

        {/* Track */}
        <div className="w-full h-2.5 bg-stone-100 dark:bg-stone-800 rounded-full overflow-hidden p-0.5 border border-stone-200/60 dark:border-stone-700/60">
          <div
            className={`h-full rounded-full transition-all duration-500 ease-out ${
              isAccomplished
                ? 'bg-linear-to-r from-emerald-500 to-teal-400'
                : percentage >= 75
                ? 'bg-linear-to-r from-blue-500 to-indigo-500'
                : percentage >= 50
                ? 'bg-linear-to-r from-rose-500 to-amber-500'
                : 'bg-rose-500'
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      {/* Expanded Controls & Insights */}
      {isExpanded && (
        <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800/80 flex flex-col gap-3">
          {/* Preset Buttons & Custom Stepper */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs text-stone-400 font-medium mr-1">
                ലക്ഷ്യം തിരഞ്ഞെടുക്കുക:
              </span>
              {PRESET_GOALS.map((preset) => (
                <button
                  key={preset.words}
                  onClick={() => onUpdateGoal(preset.words)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    goal === preset.words
                      ? 'bg-rose-600 text-white shadow-2xs'
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
                  }`}
                >
                  {preset.words} {preset.label.split(' ')[0]}
                </button>
              ))}
            </div>

            {/* Custom Stepper */}
            <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800 rounded-lg p-0.5 border border-stone-200 dark:border-stone-700 text-xs">
              <button
                onClick={() => onUpdateGoal(Math.max(50, goal - 50))}
                className="p-1 rounded-md hover:bg-white dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300"
                title="Decrease goal by 50 words"
              >
                <Minus className="w-3 h-3" />
              </button>
              <span className="px-2 font-mono font-semibold text-stone-800 dark:text-stone-200">
                {goal}
              </span>
              <button
                onClick={() => onUpdateGoal(goal + 50)}
                className="p-1 rounded-md hover:bg-white dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300"
                title="Increase goal by 50 words"
              >
                <Plus className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Milestones Checkpoint Chips */}
          <div className="grid grid-cols-4 gap-2 pt-1">
            {[
              { mark: 25, label: 'തുടക്കം (Start)', done: percentage >= 25 },
              { mark: 50, label: 'പകുതി (Halfway)', done: percentage >= 50 },
              { mark: 75, label: 'അടുത്തെത്തി (Near)', done: percentage >= 75 },
              { mark: 100, label: 'വിജയം (Goal)', done: percentage >= 100 },
            ].map((cp) => (
              <div
                key={cp.mark}
                className={`flex items-center gap-1.5 p-2 rounded-xl border text-[11px] font-medium transition-colors ${
                  cp.done
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-300'
                    : 'bg-stone-50 dark:bg-stone-850/50 border-stone-200 dark:border-stone-800 text-stone-400 dark:text-stone-500'
                }`}
              >
                {cp.done ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                ) : (
                  <span className="w-3.5 h-3.5 rounded-full border border-stone-300 dark:border-stone-600 shrink-0" />
                )}
                <span className="truncate">{cp.mark}% {cp.label.split(' ')[0]}</span>
              </div>
            ))}
          </div>

          {/* Reading Time & Motivational Message */}
          <div className="flex items-center justify-between gap-3 text-xs text-stone-500 dark:text-stone-400 pt-1 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-stone-400" />
              <span>വായനാ സമയം: ഏകദേശം {readingTimeMinutes} മിനിറ്റ് (Reading Time)</span>
            </div>

            {isAccomplished ? (
              <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium">
                <Sparkles className="w-3.5 h-3.5" />
                <span>അഭിനന്ദനങ്ങൾ! ഇന്നത്തെ എഴുത്ത് ദൗത്യം വിജയകരം!</span>
              </div>
            ) : (
              <div className="text-stone-400">
                <span>{wordsRemaining} വാക്കുകൾ കൂടി എഴുതിയാൽ ദൗത്യം പൂർത്തിയാകും.</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Keyboard as KeyboardIcon, ChevronDown, Check } from 'lucide-react';
import { KeyboardLayoutType } from '../../types';
import { layoutLabels } from '../../lib/keyboardLayouts';

interface EditorStatusBarProps {
  wordCount: number;
  characterCount: number;
  charsNoSpaces: number;
  currentLayout: KeyboardLayoutType;
  onLayoutChange: (layout: KeyboardLayoutType) => void;
  showKeyboard: boolean;
  onToggleKeyboard: () => void;
  wordGoal?: number;
  onToggleMission?: () => void;
}

export const EditorStatusBar: React.FC<EditorStatusBarProps> = ({
  wordCount,
  characterCount,
  charsNoSpaces,
  currentLayout,
  onLayoutChange,
  showKeyboard,
  onToggleKeyboard,
  wordGoal,
  onToggleMission,
}) => {
  const [layoutMenuOpen, setLayoutMenuOpen] = React.useState(false);
  const layouts: KeyboardLayoutType[] = [
    'inscript',
    'gist',
    'typewriter',
    'panchari',
    'varityper',
    'english',
  ];

  const goal = wordGoal || 500;
  const percentage = Math.min(100, Math.round((wordCount / goal) * 100));
  const isAccomplished = wordCount >= goal;

  return (
    <div className="flex items-center justify-between gap-4 px-3 py-2 bg-stone-100/90 dark:bg-stone-900/90 border-t border-stone-200 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-400 select-none flex-wrap no-print">
      {/* Left: Counters */}
      <div className="flex items-center gap-4 sm:gap-6 font-mono text-[11px] sm:text-xs">
        <div>
          <span className="text-stone-400 dark:text-stone-500 font-sans">Words: </span>
          <span className="font-semibold text-stone-900 dark:text-stone-100">{wordCount}</span>
        </div>
        <div>
          <span className="text-stone-400 dark:text-stone-500 font-sans">Characters: </span>
          <span className="font-semibold text-stone-900 dark:text-stone-100">{characterCount}</span>
        </div>
        <div className="hidden xs:block">
          <span className="text-stone-400 dark:text-stone-500 font-sans">Excl. spaces: </span>
          <span className="font-semibold text-stone-900 dark:text-stone-100">{charsNoSpaces}</span>
        </div>

        {/* Word Goal pill in status bar */}
        {onToggleMission && (
          <button
            onClick={onToggleMission}
            title="Writing Mission Goal"
            className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-rose-300 font-sans text-[11px] cursor-pointer transition-colors"
          >
            <span className="text-stone-400">Goal:</span>
            <span className="font-semibold text-stone-800 dark:text-stone-200">
              {wordCount}/{goal}
            </span>
            <span
              className={`font-semibold ${
                isAccomplished ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              ({percentage}%)
            </span>
          </button>
        )}
      </div>

      {/* Right: Keyboard & Language status */}
      <div className="flex items-center gap-2 sm:gap-4 ml-auto">
        {/* Layout Switcher */}
        <div className="relative">
          <button
            onClick={() => setLayoutMenuOpen(!layoutMenuOpen)}
            className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:border-rose-300 dark:hover:border-rose-700 text-stone-800 dark:text-stone-200 font-medium transition-colors"
          >
            <KeyboardIcon className="w-3.5 h-3.5 text-rose-500" />
            <span>Layout: {layoutLabels[currentLayout]}</span>
            <ChevronDown className="w-3 h-3 text-stone-400" />
          </button>

          {layoutMenuOpen && (
            <>
              <div
                className="fixed inset-0 z-20"
                onClick={() => setLayoutMenuOpen(false)}
              />
              <div className="absolute bottom-full right-0 mb-1.5 w-40 bg-white dark:bg-stone-800 rounded-xl shadow-lg border border-stone-200 dark:border-stone-700 py-1 z-30 animate-in fade-in zoom-in-95 duration-100">
                {layouts.map((lt) => (
                  <button
                    key={lt}
                    onClick={() => {
                      onLayoutChange(lt);
                      setLayoutMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 flex items-center justify-between text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors"
                  >
                    <span>{layoutLabels[lt]}</span>
                    {currentLayout === lt && (
                      <Check className="w-3.5 h-3.5 text-rose-500" />
                    )}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Keyboard Visibility Toggle */}
        <button
          onClick={onToggleKeyboard}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-md border text-[11px] font-medium transition-colors ${
            showKeyboard
              ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/60'
              : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-400 border-stone-200 dark:border-stone-700'
          }`}
        >
          <span>{showKeyboard ? 'Keyboard: On' : 'Keyboard: Off'}</span>
        </button>

        {/* Language Badge */}
        <div className="hidden sm:flex items-center gap-1.5 px-2 py-1 rounded-md bg-stone-200/60 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span>Malayalam (മലയാളം)</span>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { UploadCloud, FileText, CheckCircle2, Loader2, X, ArrowRight } from 'lucide-react';
import { extractTextFromFile } from '../../services/ocrService';
import { translateToMalayalam } from '../../services/translationService';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  hasExistingText: boolean;
  onInsertText: (translatedText: string, mode: 'replace' | 'append') => void;
}

export const ImportModal: React.FC<ImportModalProps> = ({
  isOpen,
  onClose,
  hasExistingText,
  onInsertText,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedText, setExtractedText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [detectedLang, setDetectedLang] = useState('');
  const [statusStep, setStatusStep] = useState<string>('');
  const [confirmChoice, setConfirmChoice] = useState<'prompt' | 'ready'>('ready');

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    processFile(selected);
  };

  const processFile = async (uploadedFile: File) => {
    try {
      setIsProcessing(true);
      setStatusStep('Extracting text from file...');

      const ocrRes = await extractTextFromFile(uploadedFile);
      setExtractedText(ocrRes.text);
      setDetectedLang(ocrRes.detectedLanguage || 'Unknown');

      setStatusStep('Translating to Malayalam...');
      const transRes = await translateToMalayalam({
        text: ocrRes.text,
        sourceLanguage: 'auto',
      });

      setTranslatedText(transRes.translatedText);
      setStatusStep('Completed');
    } catch (err: unknown) {
      console.error('Import error', err);
      setStatusStep('Error occurred while processing');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleInsert = (mode: 'replace' | 'append') => {
    onInsertText(translatedText, mode);
    handleClose();
  };

  const handleClose = () => {
    setFile(null);
    setExtractedText('');
    setTranslatedText('');
    setStatusStep('');
    setConfirmChoice('ready');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl max-w-xl w-full p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-stone-100 dark:border-stone-800">
          <div>
            <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
              Import &amp; Translate Document
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              Upload TXT, MD, DOCX, or PDF to extract and translate into Malayalam
            </p>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Zone */}
        {!translatedText && (
          <div className="mt-6">
            <label className="flex flex-col items-center justify-center border-2 border-dashed border-stone-300 dark:border-stone-700 hover:border-rose-400 dark:hover:border-rose-500 rounded-xl p-8 cursor-pointer transition-colors bg-stone-50/50 dark:bg-stone-800/30">
              <UploadCloud className="w-10 h-10 text-rose-500 mb-3" />
              <span className="text-sm font-semibold text-stone-800 dark:text-stone-200">
                Click to browse or drop document here
              </span>
              <span className="text-xs text-stone-400 mt-1">
                Supports .txt, .md, .docx, and .pdf
              </span>
              <input
                type="file"
                accept=".txt,.md,.docx,.pdf,text/plain,application/pdf"
                onChange={handleFileChange}
                disabled={isProcessing}
                className="hidden"
              />
            </label>

            {isProcessing && (
              <div className="mt-6 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 flex items-center gap-3">
                <Loader2 className="w-5 h-5 text-rose-600 animate-spin" />
                <div className="text-xs">
                  <div className="font-semibold text-rose-900 dark:text-rose-200">
                    {statusStep}
                  </div>
                  <div className="text-rose-700 dark:text-rose-300">
                    Processing {file?.name}...
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Preview and Insert */}
        {translatedText && (
          <div className="mt-6 space-y-4">
            <div className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2 text-stone-700 dark:text-stone-300">
                <FileText className="w-4 h-4 text-rose-500" />
                <span className="font-semibold">{file?.name}</span>
                <span className="text-stone-400">({detectedLang})</span>
              </div>
              <span className="flex items-center gap-1 text-emerald-600 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> Translated
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1 block">
                Malayalam Translation Preview:
              </label>
              <textarea
                rows={6}
                value={translatedText}
                onChange={(e) => setTranslatedText(e.target.value)}
                className="w-full p-3 text-sm rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 font-noto-sans outline-none focus:ring-2 focus:ring-rose-500/20"
              />
            </div>

            {hasExistingText && confirmChoice === 'ready' ? (
              <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 rounded-xl space-y-3 text-xs text-amber-900 dark:text-amber-200">
                <div className="font-semibold">
                  Your document already contains text. How would you like to continue?
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleInsert('replace')}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-medium transition-colors"
                  >
                    Replace current text
                  </button>
                  <button
                    onClick={() => handleInsert('append')}
                    className="px-3 py-1.5 rounded-lg bg-stone-800 dark:bg-stone-700 text-white hover:bg-stone-700 font-medium transition-colors"
                  >
                    Append translation
                  </button>
                  <button
                    onClick={handleClose}
                    className="px-3 py-1.5 rounded-lg border border-amber-300 dark:border-amber-800 hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={handleClose}
                  className="px-4 py-2 text-xs rounded-xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleInsert('replace')}
                  className="px-4 py-2 text-xs rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold flex items-center gap-1.5"
                >
                  <span>Insert into Writer</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

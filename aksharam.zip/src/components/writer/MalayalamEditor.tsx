import React, { useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { KeyboardLayoutType, FontFamilyChoice } from '../../types';
import { getMappedCharacter } from '../../lib/keyboardLayouts';
import { playKeyClickSound } from '../../services/keyboardService';

export interface MalayalamEditorHandle {
  insertText: (text: string) => void;
  deleteBackward: () => void;
  insertNewline: () => void;
  focus: () => void;
  selectRange: (start: number, end: number) => void;
  getText: () => string;
}

interface MalayalamEditorProps {
  content: string;
  onChange: (newContent: string) => void;
  layout: KeyboardLayoutType;
  fontFamily: FontFamilyChoice;
  fontSize: number;
  editorWidth: 'narrow' | 'medium' | 'wide' | 'full';
  soundEnabled: boolean;
  onSaveShortcut?: () => void;
  onFindShortcut?: () => void;
  onPrintShortcut?: () => void;
  onNewShortcut?: () => void;
  onUndoShortcut?: () => void;
  onRedoShortcut?: () => void;
}

export const MalayalamEditor = forwardRef<MalayalamEditorHandle, MalayalamEditorProps>(
  (
    {
      content,
      onChange,
      layout,
      fontFamily,
      fontSize,
      editorWidth,
      soundEnabled,
      onSaveShortcut,
      onFindShortcut,
      onPrintShortcut,
      onNewShortcut,
      onUndoShortcut,
      onRedoShortcut,
    },
    ref
  ) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Expose methods to parent (e.g. for on-screen keyboard, find/replace)
    useImperativeHandle(ref, () => ({
      insertText: (text: string) => {
        if (!textareaRef.current) return;
        const textarea = textareaRef.current;
        const start = textarea.selectionStart ?? textarea.value.length;
        const end = textarea.selectionEnd ?? textarea.value.length;
        const val = textarea.value;

        const updated = val.substring(0, start) + text + val.substring(end);
        onChange(updated);

        // Maintain cursor
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.selectionStart = start + text.length;
            textareaRef.current.selectionEnd = start + text.length;
            textareaRef.current.focus();
          }
        }, 0);
      },
      deleteBackward: () => {
        if (!textareaRef.current) return;
        const textarea = textareaRef.current;
        const start = textarea.selectionStart ?? textarea.value.length;
        const end = textarea.selectionEnd ?? textarea.value.length;
        const val = textarea.value;

        if (start === end && start > 0) {
          const updated = val.substring(0, start - 1) + val.substring(end);
          onChange(updated);
          setTimeout(() => {
            if (textareaRef.current) {
              textareaRef.current.selectionStart = start - 1;
              textareaRef.current.selectionEnd = start - 1;
            }
          }, 0);
        } else if (start !== end) {
          const updated = val.substring(0, start) + val.substring(end);
          onChange(updated);
          setTimeout(() => {
            if (textareaRef.current) {
              textareaRef.current.selectionStart = start;
              textareaRef.current.selectionEnd = start;
            }
          }, 0);
        }
      },
      insertNewline: () => {
        if (!textareaRef.current) return;
        const textarea = textareaRef.current;
        const start = textarea.selectionStart ?? textarea.value.length;
        const end = textarea.selectionEnd ?? textarea.value.length;
        const val = textarea.value;

        const updated = val.substring(0, start) + '\n' + val.substring(end);
        onChange(updated);
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.selectionStart = start + 1;
            textareaRef.current.selectionEnd = start + 1;
          }
        }, 0);
      },
      focus: () => {
        textareaRef.current?.focus();
      },
      selectRange: (start: number, end: number) => {
        if (!textareaRef.current) return;
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(start, end);
        // Scroll to selection if possible
      },
      getText: () => content,
    }));

    // Handle physical keyboard input
    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      // Check for global application shortcuts
      if ((e.ctrlKey || e.metaKey) && !e.altKey) {
        const key = e.key.toLowerCase();
        if (key === 's') {
          e.preventDefault();
          onSaveShortcut?.();
          return;
        }
        if (key === 'f') {
          e.preventDefault();
          onFindShortcut?.();
          return;
        }
        if (key === 'p') {
          e.preventDefault();
          onPrintShortcut?.();
          return;
        }
        if (key === 'n') {
          e.preventDefault();
          onNewShortcut?.();
          return;
        }
        if (key === 'z') {
          if (e.shiftKey) {
            e.preventDefault();
            onRedoShortcut?.();
          } else {
            e.preventDefault();
            onUndoShortcut?.();
          }
          return;
        }
        if (key === 'y') {
          e.preventDefault();
          onRedoShortcut?.();
          return;
        }
        return; // Allow standard shortcuts like Ctrl+C, Ctrl+V, Ctrl+A to work natively
      }

      // Allow navigation keys
      if (
        e.key === 'ArrowLeft' ||
        e.key === 'ArrowRight' ||
        e.key === 'ArrowUp' ||
        e.key === 'ArrowDown' ||
        e.key === 'Home' ||
        e.key === 'End' ||
        e.key === 'PageUp' ||
        e.key === 'PageDown' ||
        e.key === 'Escape'
      ) {
        return;
      }

      // If layout is English, let native browser input happen
      if (layout === 'english') {
        if (soundEnabled && e.key.length === 1) {
          playKeyClickSound();
        }
        return;
      }

      // For Malayalam Inscript / GIST / Typewriter / etc., intercept keystroke and map to Unicode
      const nativeEvent = e.nativeEvent;
      const mappedChar = getMappedCharacter(nativeEvent, layout);

      if (mappedChar !== null) {
        e.preventDefault();
        if (soundEnabled) {
          playKeyClickSound();
        }

        const textarea = textareaRef.current;
        if (!textarea) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const val = textarea.value;

        const updated = val.substring(0, start) + mappedChar + val.substring(end);
        onChange(updated);

        // Move cursor forward
        const newPos = start + mappedChar.length;
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.selectionStart = newPos;
            textareaRef.current.selectionEnd = newPos;
          }
        }, 0);
      }
    };

    // Width classes
    const widthClasses = {
      narrow: 'max-w-2xl',
      medium: 'max-w-4xl',
      wide: 'max-w-5xl',
      full: 'max-w-full',
    }[editorWidth];

    // Font family class
    const fontClass = {
      'Noto Sans Malayalam': 'font-noto-sans',
      'Noto Serif Malayalam': 'font-noto-serif',
      'Manjari': 'font-manjari',
      'Gayathri': 'font-gayathri',
    }[fontFamily] || 'font-noto-sans';

    return (
      <div className={`w-full mx-auto ${widthClasses} flex-1 flex flex-col transition-all print-document-container`}>
        <div className="flex-1 bg-white dark:bg-stone-900/90 rounded-2xl border border-stone-200/80 dark:border-stone-800 shadow-sm flex flex-col overflow-hidden">
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="ഇവിടെ മലയാളത്തിൽ ടൈപ്പ് ചെയ്യുക... (Type Malayalam here using Inscript or On-screen keyboard)"
            style={{ fontSize: `${fontSize}px` }}
            className={`
              flex-1 w-full p-4 sm:p-8 bg-transparent text-stone-900 dark:text-stone-100 outline-none resize-none
              ${fontClass} leading-relaxed placeholder:text-stone-400 dark:placeholder:text-stone-500
              selection:bg-rose-500/20 dark:selection:bg-rose-500/30 print-document-content
            `}
            spellCheck={false}
          />
        </div>
      </div>
    );
  }
);
MalayalamEditor.displayName = 'MalayalamEditor';

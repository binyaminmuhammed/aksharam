import React, { useState } from 'react';
import {
  FilePlus,
  FolderOpen,
  Save,
  Download,
  Printer,
  Copy,
  Trash2,
  Undo2,
  Redo2,
  Search,
  Languages,
  Share2,
  FileUp,
  ChevronDown,
  FileText,
  FileCode,
  Target,
} from 'lucide-react';

interface WriterToolbarProps {
  onNew: () => void;
  onOpen: () => void;
  onSave: () => void;
  onDownloadTxt: () => void;
  onDownloadDocx: () => void;
  onPrint: () => void;
  onCopy: () => void;
  onClear: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onToggleFind: () => void;
  onGoToTranslate: () => void;
  onShare: () => void;
  onOpenImport: () => void;
  onToggleMission?: () => void;
  showMission?: boolean;
  wordGoalProgress?: { current: number; goal: number; percentage: number };
}

export const WriterToolbar: React.FC<WriterToolbarProps> = ({
  onNew,
  onOpen,
  onSave,
  onDownloadTxt,
  onDownloadDocx,
  onPrint,
  onCopy,
  onClear,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onToggleFind,
  onGoToTranslate,
  onShare,
  onOpenImport,
  onToggleMission,
  showMission,
  wordGoalProgress,
}) => {
  const [downloadMenuOpen, setDownloadMenuOpen] = useState(false);

  return (
    <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-1.5 shadow-xs flex items-center justify-between gap-1 flex-wrap no-print">
      {/* Group 1: Document Lifecycle */}
      <div className="flex items-center gap-1">
        <button
          onClick={onNew}
          title="New Document (Ctrl + N)"
          aria-label="New Document"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-white transition-colors"
        >
          <FilePlus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span className="hidden sm:inline">New</span>
        </button>

        <button
          onClick={onOpen}
          title="Open Document (Ctrl + O)"
          aria-label="Open Document"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-white transition-colors"
        >
          <FolderOpen className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          <span className="hidden sm:inline">Open</span>
        </button>

        <button
          onClick={onSave}
          title="Save Document (Ctrl + S)"
          aria-label="Save Document"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-white transition-colors"
        >
          <Save className="w-4 h-4 text-sky-600 dark:text-sky-400" />
          <span className="hidden sm:inline">Save</span>
        </button>
      </div>

      <div className="w-[1px] h-5 bg-stone-200 dark:bg-stone-800 my-auto hidden xs:block" />

      {/* Group 2: History & Editing */}
      <div className="flex items-center gap-1">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          title="Undo (Ctrl + Z)"
          aria-label="Undo"
          className="p-1.5 rounded-lg text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          <Undo2 className="w-4 h-4" />
        </button>

        <button
          onClick={onRedo}
          disabled={!canRedo}
          title="Redo (Ctrl + Y)"
          aria-label="Redo"
          className="p-1.5 rounded-lg text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          <Redo2 className="w-4 h-4" />
        </button>

        <button
          onClick={onCopy}
          title="Copy Text to Clipboard"
          aria-label="Copy"
          className="p-1.5 rounded-lg text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <Copy className="w-4 h-4" />
        </button>

        <button
          onClick={onClear}
          title="Clear Document"
          aria-label="Clear"
          className="p-1.5 rounded-lg text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="w-[1px] h-5 bg-stone-200 dark:bg-stone-800 my-auto hidden sm:block" />

      {/* Group 3: Search, Tools, Translation */}
      <div className="flex items-center gap-1">
        <button
          onClick={onToggleFind}
          title="Find / Search text (Ctrl + F)"
          aria-label="Find Text"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <Search className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          <span className="hidden md:inline">Find</span>
        </button>

        {onToggleMission && (
          <button
            onClick={onToggleMission}
            title="Writing Mission & Word Goal"
            aria-label="Writing Mission"
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              showMission
                ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60'
                : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
          >
            <Target className="w-4 h-4 text-rose-600 dark:text-rose-400" />
            <span className="hidden sm:inline">Mission</span>
            {wordGoalProgress && (
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${
                  wordGoalProgress.percentage >= 100
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
                }`}
              >
                {wordGoalProgress.percentage}%
              </span>
            )}
          </button>
        )}

        <button
          onClick={onOpenImport}
          title="Import & Translate File"
          aria-label="Import File"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <FileUp className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <span className="hidden md:inline">Import &amp; Translate</span>
        </button>

        <button
          onClick={onGoToTranslate}
          title="Translate to Malayalam"
          aria-label="Translate"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
        >
          <Languages className="w-4 h-4" />
          <span className="hidden md:inline">Translate</span>
        </button>
      </div>

      <div className="w-[1px] h-5 bg-stone-200 dark:bg-stone-800 my-auto" />

      {/* Group 4: Download, Print, Share */}
      <div className="flex items-center gap-1">
        {/* Download dropdown */}
        <div className="relative">
          <button
            onClick={() => setDownloadMenuOpen(!downloadMenuOpen)}
            title="Download Document Options"
            aria-label="Download Document"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-rose-600 hover:bg-rose-700 text-white shadow-xs transition-colors"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export</span>
            <ChevronDown className="w-3 h-3 opacity-80" />
          </button>

          {downloadMenuOpen && (
            <>
              <div
                className="fixed inset-0 z-20"
                onClick={() => setDownloadMenuOpen(false)}
              />
              <div className="absolute right-0 mt-1.5 w-48 bg-white dark:bg-stone-800 rounded-xl shadow-lg border border-stone-200 dark:border-stone-700 py-1.5 z-30 animate-in fade-in zoom-in-95 duration-100 text-xs">
                <button
                  onClick={() => {
                    onDownloadTxt();
                    setDownloadMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 flex items-center gap-2"
                >
                  <FileCode className="w-4 h-4 text-emerald-600" />
                  <div>
                    <div className="font-medium">Text Document (.txt)</div>
                    <div className="text-[10px] text-stone-400">Unicode UTF-8 encoding</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    onDownloadDocx();
                    setDownloadMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 flex items-center gap-2"
                >
                  <FileText className="w-4 h-4 text-blue-600" />
                  <div>
                    <div className="font-medium">Word Document (.docx)</div>
                    <div className="text-[10px] text-stone-400">Formatted with headers</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    onPrint();
                    setDownloadMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 flex items-center gap-2"
                >
                  <Printer className="w-4 h-4 text-stone-600" />
                  <div>
                    <div className="font-medium">Print / Save as PDF</div>
                    <div className="text-[10px] text-stone-400">Browser print dialog</div>
                  </div>
                </button>
              </div>
            </>
          )}
        </div>

        <button
          onClick={onPrint}
          title="Print Document (Ctrl + P)"
          aria-label="Print Document"
          className="p-1.5 rounded-lg text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <Printer className="w-4 h-4" />
        </button>

        <button
          onClick={onShare}
          title="Share or Copy Link"
          aria-label="Share"
          className="p-1.5 rounded-lg text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

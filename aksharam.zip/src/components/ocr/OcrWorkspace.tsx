import React, { useState } from 'react';
import { 
  ScanLine, 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  Loader2, 
  Send, 
  Copy, 
  Download, 
  Check, 
  ArrowRight,
  Languages,
  FileCode
} from 'lucide-react';
import { extractTextFromFile } from '../../services/ocrService';
import { translateToMalayalam } from '../../services/translationService';
import { exportAsTxt, exportAsDocx } from '../../services/exportService';

interface OcrWorkspaceProps {
  onSendToWriter: (text: string) => void;
  showToast: (title: string, desc?: string, type?: 'success' | 'error' | 'info') => void;
}

export const OcrWorkspace: React.FC<OcrWorkspaceProps> = ({
  onSendToWriter,
  showToast,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [extractedText, setExtractedText] = useState('');
  const [translatedMalayalam, setTranslatedMalayalam] = useState('');
  const [detectedLang, setDetectedLang] = useState('');
  const [copied, setCopied] = useState(false);

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) handleFile(dropped);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) handleFile(selected);
  };

  const handleFile = (selectedFile: File) => {
    setFile(selectedFile);
    setExtractedText('');
    setTranslatedMalayalam('');

    if (selectedFile.type.startsWith('image/')) {
      const url = URL.createObjectURL(selectedFile);
      setImagePreview(url);
    } else {
      setImagePreview(null);
    }
  };

  const handleRunOcr = async () => {
    if (!file) return;

    try {
      setIsExtracting(true);
      showToast('Processing OCR...', `Extracting text from ${file.name}`, 'info');

      const ocrRes = await extractTextFromFile(file);
      setExtractedText(ocrRes.text);
      setDetectedLang(ocrRes.detectedLanguage || 'Unknown');
      showToast('Text extracted', `Identified language: ${ocrRes.detectedLanguage || 'Auto'}`, 'success');

      // If text is already predominantly Malayalam, set to translated directly
      if (/[\u0D00-\u0D7F]/.test(ocrRes.text)) {
        setTranslatedMalayalam(ocrRes.text);
      } else {
        // Automatically trigger translation into Malayalam
        setIsTranslating(true);
        const transRes = await translateToMalayalam({
          text: ocrRes.text,
          sourceLanguage: 'auto',
        });
        setTranslatedMalayalam(transRes.translatedText);
      }
    } catch (err: unknown) {
      console.error(err);
      showToast('OCR extraction failed', 'Please try another file', 'error');
    } finally {
      setIsExtracting(false);
      setIsTranslating(false);
    }
  };

  const handleCopy = () => {
    if (!translatedMalayalam) return;
    navigator.clipboard.writeText(translatedMalayalam);
    setCopied(true);
    showToast('Copied to clipboard', undefined, 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col gap-6">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2.5">
          <ScanLine className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          <span>PDF / Image to Malayalam OCR</span>
        </h2>
        <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-0.5">
          Upload a document or image, extract text via OCR, and convert/translate into Malayalam.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Upload & OCR Setup */}
        <div className="flex flex-col gap-4">
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="bg-white dark:bg-stone-900 border-2 border-dashed border-stone-300 dark:border-stone-700 hover:border-rose-400 dark:hover:border-rose-500 rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors shadow-xs"
          >
            <input
              type="file"
              accept=".pdf,image/png,image/jpeg,image/jpg,image/webp"
              onChange={handleFileChange}
              id="ocr-upload-input"
              className="hidden"
            />
            <label htmlFor="ocr-upload-input" className="cursor-pointer flex flex-col items-center">
              <div className="w-14 h-14 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3 shadow-xs">
                <UploadCloud className="w-7 h-7" />
              </div>
              <span className="text-sm font-semibold text-stone-800 dark:text-stone-200">
                {file ? file.name : 'Choose PDF or Image file'}
              </span>
              <span className="text-xs text-stone-400 dark:text-stone-500 mt-1">
                Supports PDF, PNG, JPG, JPEG documents
              </span>
            </label>

            {file && (
              <div className="mt-4 flex items-center gap-2 text-xs text-stone-600 dark:text-stone-400">
                <span>{(file.size / 1024).toFixed(1)} KB</span>
                <span>•</span>
                <span className="capitalize">{file.type.split('/')[1] || 'Document'}</span>
              </div>
            )}
          </div>

          {/* Image Thumbnail preview if image */}
          {imagePreview && (
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3 shadow-xs">
              <span className="text-xs font-semibold text-stone-400 mb-2 block">
                Preview:
              </span>
              <img
                src={imagePreview}
                alt="Upload preview"
                className="max-h-60 mx-auto rounded-xl object-contain border border-stone-100 dark:border-stone-800"
              />
            </div>
          )}

          {/* Action Button */}
          {file && (
            <button
              onClick={handleRunOcr}
              disabled={isExtracting || isTranslating}
              className="w-full py-3.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-semibold text-sm shadow-sm shadow-rose-600/20 flex items-center justify-center gap-2 transition-colors"
            >
              {isExtracting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Extracting text / OCR...</span>
                </>
              ) : isTranslating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Translating to Malayalam...</span>
                </>
              ) : (
                <>
                  <ScanLine className="w-4 h-4" />
                  <span>Extract &amp; Convert to Malayalam</span>
                </>
              )}
            </button>
          )}

          {/* Malayalam OCR Information Card (Inspired by Screenshot 4) */}
          <div className="bg-stone-50 dark:bg-stone-800/40 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
            <h4 className="font-semibold text-stone-900 dark:text-stone-200 mb-1 flex items-center gap-1.5">
              <span>Malayalam OCR Utility</span>
            </h4>
            <p>
              PDF ഫയലുകളിലെയും Image-കളിലെയും ഉള്ളടക്കം എക്സ്ട്രാക്റ്റ് ചെയ്ത് ടെക്സ്റ്റ് ആക്കി മാറ്റാനും മലയാളത്തിലേക്ക് തർജ്ജമ ചെയ്യാനും ഈ ഫീച്ചർ ഉപയോഗിക്കാം.
            </p>
          </div>
        </div>

        {/* Right Column: OCR & Malayalam Output */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between min-h-[450px]">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-400">
                  Malayalam Extracted Result
                </span>
                {detectedLang && (
                  <span className="px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-[10px] font-medium text-stone-600 dark:text-stone-300">
                    {detectedLang}
                  </span>
                )}
              </div>

              {translatedMalayalam && (
                <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Ready
                </span>
              )}
            </div>

            {/* Extracted Malayalam Output Area */}
            <textarea
              rows={14}
              value={translatedMalayalam}
              onChange={(e) => setTranslatedMalayalam(e.target.value)}
              placeholder="OCR എക്സ്ട്രാക്റ്റ് ചെയ്ത മലയാളം ടെക്സ്റ്റ് ഇവിടെ ദൃശ്യമാകും... (Extracted and translated text will appear here and can be freely edited)"
              className="w-full py-4 bg-transparent text-sm sm:text-base text-stone-900 dark:text-stone-100 outline-none resize-none leading-relaxed font-noto-sans placeholder:text-stone-400"
            />
          </div>

          {/* Action Bar */}
          <div className="flex items-center justify-between pt-3 border-t border-stone-100 dark:border-stone-800 gap-2 flex-wrap text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                disabled={!translatedMalayalam}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 disabled:opacity-40 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={() => exportAsTxt('OCR_Malayalam_Document', translatedMalayalam)}
                disabled={!translatedMalayalam}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 disabled:opacity-40 transition-colors"
                title="Download as TXT"
              >
                <FileCode className="w-3.5 h-3.5 text-emerald-600" />
                <span>TXT</span>
              </button>

              <button
                onClick={() => exportAsDocx('OCR_Malayalam_Document', translatedMalayalam)}
                disabled={!translatedMalayalam}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 disabled:opacity-40 transition-colors"
                title="Download as DOCX"
              >
                <Download className="w-3.5 h-3.5 text-blue-600" />
                <span>DOCX</span>
              </button>
            </div>

            <button
              onClick={() => onSendToWriter(translatedMalayalam)}
              disabled={!translatedMalayalam}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white font-medium shadow-2xs transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send to Writer</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

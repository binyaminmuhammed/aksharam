import React, { useState } from 'react';
import { 
  DocumentItem 
} from '../../types';
import { 
  FileText, 
  Search, 
  FolderPlus, 
  Trash2, 
  Copy, 
  Download, 
  Edit3, 
  Clock, 
  FileCode, 
  Check, 
  Calendar 
} from 'lucide-react';
import { exportAsTxt, exportAsDocx } from '../../services/exportService';

interface DocumentListProps {
  documents: DocumentItem[];
  activeDocId: string;
  onSelectDocument: (doc: DocumentItem) => void;
  onCreateNew: () => void;
  onRename: (id: string, newTitle: string) => void;
  onDuplicate: (doc: DocumentItem) => void;
  onDelete: (id: string) => void;
  showToast: (title: string, desc?: string, type?: 'success' | 'error' | 'info') => void;
}

export const DocumentList: React.FC<DocumentListProps> = ({
  documents,
  activeDocId,
  onSelectDocument,
  onCreateNew,
  onRename,
  onDuplicate,
  onDelete,
  showToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const filteredDocs = documents.filter((doc) => {
    const q = searchQuery.toLowerCase();
    return (
      doc.title.toLowerCase().includes(q) ||
      doc.content.toLowerCase().includes(q)
    );
  });

  const startRename = (doc: DocumentItem) => {
    setEditingId(doc.id);
    setEditingTitle(doc.title);
  };

  const saveRename = (id: string) => {
    if (editingTitle.trim()) {
      onRename(id, editingTitle.trim());
      showToast('Document renamed', undefined, 'success');
    }
    setEditingId(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col gap-6">
      {/* Header & Controls */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-rose-600 dark:text-rose-400" />
            <span>Malayalam Documents</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-0.5">
            Manage your saved Malayalam documents, drafts, and notes.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Search bar */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-xs w-48 sm:w-64">
            <Search className="w-4 h-4 text-stone-400" />
            <input
              type="text"
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-stone-900 dark:text-stone-100 outline-none"
            />
          </div>

          <button
            onClick={onCreateNew}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <FolderPlus className="w-4 h-4" />
            <span>New Document</span>
          </button>
        </div>
      </div>

      {/* Grid of Documents */}
      {filteredDocs.length === 0 ? (
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 p-12 text-center flex flex-col items-center">
          <div className="w-12 h-12 rounded-2xl bg-stone-100 dark:bg-stone-800 text-stone-400 flex items-center justify-center mb-3">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="font-semibold text-stone-800 dark:text-stone-200">
            No documents found
          </h3>
          <p className="text-xs text-stone-400 max-w-xs mt-1">
            {searchQuery ? 'Try adjusting your search keywords.' : 'Create a new document to start writing Malayalam.'}
          </p>
          <button
            onClick={onCreateNew}
            className="mt-4 px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold"
          >
            Create First Document
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocs.map((doc) => {
            const isActive = doc.id === activeDocId;
            return (
              <div
                key={doc.id}
                className={`group bg-white dark:bg-stone-900 rounded-2xl border transition-all flex flex-col justify-between p-4 shadow-2xs hover:shadow-md ${
                  isActive
                    ? 'border-rose-400 dark:border-rose-600/80 ring-2 ring-rose-500/10'
                    : 'border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700'
                }`}
              >
                <div>
                  {/* Title or Rename Form */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    {editingId === doc.id ? (
                      <div className="flex items-center gap-1.5 w-full">
                        <input
                          type="text"
                          value={editingTitle}
                          onChange={(e) => setEditingTitle(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') saveRename(doc.id);
                            if (e.key === 'Escape') setEditingId(null);
                          }}
                          autoFocus
                          className="flex-1 px-2 py-1 text-sm font-semibold rounded bg-stone-50 dark:bg-stone-800 border border-rose-300 dark:border-rose-700 outline-none"
                        />
                        <button
                          onClick={() => saveRename(doc.id)}
                          className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <h3
                        onClick={() => onSelectDocument(doc)}
                        className="font-semibold text-stone-900 dark:text-stone-100 text-sm hover:text-rose-600 dark:hover:text-rose-400 cursor-pointer truncate"
                        title={doc.title}
                      >
                        {doc.title}
                      </h3>
                    )}

                    {isActive && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 shrink-0">
                        Current
                      </span>
                    )}
                  </div>

                  {/* Content Preview */}
                  <p
                    onClick={() => onSelectDocument(doc)}
                    className="text-xs text-stone-500 dark:text-stone-400 line-clamp-3 leading-relaxed cursor-pointer font-noto-sans"
                  >
                    {doc.content || 'ശൂന്യമായ രേഖ (Empty document)...'}
                  </p>
                </div>

                {/* Metadata & Actions */}
                <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[11px] text-stone-400">
                  <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                    <span>{doc.wordCount} words</span>
                    {doc.wordGoal && (
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                        🎯 {Math.min(100, Math.round((doc.wordCount / doc.wordGoal) * 100))}%
                      </span>
                    )}
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(doc.updatedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => startRename(doc)}
                      title="Rename Document"
                      className="p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-500"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onDuplicate(doc)}
                      title="Duplicate Document"
                      className="p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-500"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => exportAsTxt(doc.title, doc.content)}
                      title="Download as TXT"
                      className="p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-500"
                    >
                      <FileCode className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => exportAsDocx(doc.title, doc.content)}
                      title="Download as DOCX"
                      className="p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-500"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onDelete(doc.id)}
                      title="Delete Document"
                      className="p-1 rounded hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

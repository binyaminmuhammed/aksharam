import React, { useState } from 'react';
import {
  Languages,
  ArrowRight,
  Copy,
  Download,
  FileText,
  Upload,
  Trash2,
  ClipboardPaste,
  Check,
  Send,
  Loader2,
  FileCode,
} from 'lucide-react';
import { supportedSourceLanguages, translateToMalayalam } from '../../services/translationService';
import { extractTextFromFile } from '../../services/ocrService';
import { exportAsTxt, exportAsDocx } from '../../services/exportService';

interface TranslationWorkspaceProps {
  onSendToWriter: (malayalamText: string) => void;
  showToast: (title: string, desc?: string, type?: 'success' | 'error' | 'info') => void;
}

export const TranslationWorkspace: React.FC<TranslationWorkspaceProps> = ({
  onSendToWriter,
  showToast,
}) => {
  const [sourceLang, setSourceLang] = useState('auto');
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [detectedLang, setDetectedLang] = useState<string | null>(null);
  const [providerName, setProviderName] = useState<string | null>(null);
  const [uploadedFileInfo, setUploadedFileInfo] = useState<{
    name: string;
    size: number;
    type: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  // Quick sample prompts
  const samplePrompts = [
    'Welcome to our home',
    'How are you today?',
    'Today is a wonderful day to write stories in Malayalam',
    'Knowledge is power and wisdom is freedom',
  ];

  // Handle manual paste from clipboard
  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setSourceText(text);
      showToast('Pasted from clipboard', undefined, 'info');
    } catch {
      showToast('Clipboard access denied', 'Please paste using Ctrl + V', 'error');
    }
  };

  // Handle File Upload for translation
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileInfo({
      name: file.name,
      size: file.size,
      type: file.type || 'document',
    });

    try {
      showToast('Extracting text from file...', file.name, 'info');
      const ocrRes = await extractTextFromFile(file);
      setSourceText(ocrRes.text);
      if (ocrRes.detectedLanguage && ocrRes.detectedLanguage !== 'Unknown') {
        setDetectedLang(ocrRes.detectedLanguage);
      }
      showToast('File loaded', `${file.name} ready to translate`, 'success');
    } catch (err: unknown) {
      console.error(err);
      showToast('Failed to load file', 'Could not extract text from document', 'error');
    }
  };

  // Handle Translate
  const handleTranslate = async () => {
    if (!sourceText.trim()) {
      showToast('Please enter or upload text to translate', undefined, 'error');
      return;
    }

    try {
      setIsTranslating(true);
      const res = await translateToMalayalam({
        text: sourceText,
        sourceLanguage: sourceLang,
      });

      setTranslatedText(res.translatedText);
      if (res.detectedLanguage) {
        setDetectedLang(res.detectedLanguage);
      }
      if (res.provider) {
        setProviderName(res.provider);
      }
      showToast('Translation completed', `Powered by ${res.provider}`, 'success');
    } catch (err: unknown) {
      console.error(err);
      showToast('Translation failed', 'Please check network and try again', 'error');
    } finally {
      setIsTranslating(false);
    }
  };

  // Handle Copy
  const handleCopy = () => {
    if (!translatedText) return;
    navigator.clipboard.writeText(translatedText);
    setCopied(true);
    showToast('Copied to clipboard', 'Malayalam translation copied', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  // Clear
  const handleClear = () => {
    setSourceText('');
    setUploadedFileInfo(null);
    setDetectedLang(null);
    setProviderName(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col gap-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2.5">
            <Languages className="w-6 h-6 text-rose-600 dark:text-rose-400" />
            <span>Translate to Malayalam</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-0.5">
            Translate documents or text from any language into authentic, fluent Malayalam Unicode.
          </p>
        </div>

        {/* Quick sample prompt chips */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs text-stone-400 dark:text-stone-500 font-medium">Try:</span>
          {samplePrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => {
                setSourceText(prompt);
                setSourceLang('en');
              }}
              className="text-[11px] px-2.5 py-1 rounded-full bg-stone-100 dark:bg-stone-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-stone-600 dark:text-stone-300 hover:text-rose-600 border border-stone-200 dark:border-stone-700 hover:border-rose-300 transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>

        {uploadedFileInfo && (
          <div className="flex items-center gap-3 px-3 py-1.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-xl text-xs text-rose-800 dark:text-rose-200">
            <FileText className="w-4 h-4 text-rose-600" />
            <div>
              <span className="font-semibold">{uploadedFileInfo.name}</span>
              <span className="text-stone-400 dark:text-stone-500 ml-1.5">
                ({(uploadedFileInfo.size / 1024).toFixed(1)} KB)
              </span>
            </div>
            <button
              onClick={() => setUploadedFileInfo(null)}
              className="text-stone-400 hover:text-stone-600 ml-2"
            >
              ✕
            </button>
          </div>
        )}
      </div>

      {/* Grid: Left Panel | Center Button | Right Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-4 items-stretch">
        {/* Left Panel: Source Text */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800 gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-400">
                Source Text
              </span>
              {detectedLang && (
                <span className="px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-[10px] font-medium text-stone-600 dark:text-stone-300">
                  Detected: {detectedLang}
                </span>
              )}
            </div>

            {/* Language Dropdown */}
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value)}
              className="px-2.5 py-1 text-xs rounded-lg bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200 outline-none focus:ring-2 focus:ring-rose-500/20"
            >
              {supportedSourceLanguages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          {/* Text Area */}
          <textarea
            rows={14}
            value={sourceText}
            onChange={(e) => setSourceText(e.target.value)}
            onKeyDown={(e) => {
              if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                handleTranslate();
              }
            }}
            placeholder="Type, paste, or upload text in English, Hindi, Tamil, Arabic, etc. (Press Ctrl+Enter to translate)..."
            className="w-full flex-1 py-4 bg-transparent text-sm sm:text-base text-stone-900 dark:text-stone-100 outline-none resize-none leading-relaxed placeholder:text-stone-400"
          />

          {/* Bottom Controls */}
          <div className="flex items-center justify-between pt-3 border-t border-stone-100 dark:border-stone-800 gap-2 flex-wrap text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={handlePaste}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 transition-colors"
              >
                <ClipboardPaste className="w-3.5 h-3.5 text-stone-500" />
                <span>Paste</span>
              </button>

              <label className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 cursor-pointer transition-colors">
                <Upload className="w-3.5 h-3.5 text-rose-500" />
                <span>Upload File</span>
                <input
                  type="file"
                  accept=".txt,.md,.docx,.pdf,text/plain,application/pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              {sourceText && (
                <button
                  onClick={handleClear}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-stone-100 dark:hover:bg-stone-800"
                  title="Clear source text"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <span className="text-stone-400 font-mono">
              {sourceText.length} chars
            </span>
          </div>
        </div>

        {/* Center Action: Translate Button */}
        <div className="flex lg:flex-col items-center justify-center gap-3 self-center my-2 lg:my-0">
          <button
            onClick={handleTranslate}
            disabled={isTranslating || !sourceText.trim()}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-semibold shadow-md shadow-rose-600/20 active:scale-95 transition-all w-full lg:w-auto"
          >
            {isTranslating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="text-xs sm:text-sm">Translating...</span>
              </>
            ) : (
              <>
                <span className="text-xs sm:text-sm">Translate to Malayalam</span>
                <ArrowRight className="w-4 h-4 hidden lg:inline" />
              </>
            )}
          </button>
        </div>

        {/* Right Panel: Malayalam Translation */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800 gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-400">
                Malayalam Translation (മലയാള തർജ്ജമ)
              </span>
            </div>

            <div className="flex items-center gap-2">
              {providerName && (
                <span className="text-[10px] text-stone-500 dark:text-stone-400 bg-stone-100 dark:bg-stone-800 px-2 py-0.5 rounded-full font-mono">
                  {providerName}
                </span>
              )}
              <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full">
                Editable Unicode
              </span>
            </div>
          </div>

          {/* Malayalam Output Area (Editable) */}
          <textarea
            rows={14}
            value={translatedText}
            onChange={(e) => setTranslatedText(e.target.value)}
            placeholder="മലയാള തർജ്ജമ ഇവിടെ ലഭിക്കും... (Malayalam translated text will appear here and remains editable)"
            className="w-full flex-1 py-4 bg-transparent text-sm sm:text-base text-stone-900 dark:text-stone-100 outline-none resize-none leading-relaxed font-noto-sans placeholder:text-stone-400"
          />

          {/* Bottom Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-stone-100 dark:border-stone-800 gap-2 flex-wrap text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                disabled={!translatedText}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 disabled:opacity-40 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={() => exportAsTxt('Malayalam_Translation', translatedText)}
                disabled={!translatedText}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 disabled:opacity-40 transition-colors"
                title="Download as TXT"
              >
                <FileCode className="w-3.5 h-3.5 text-emerald-600" />
                <span>TXT</span>
              </button>

              <button
                onClick={() => exportAsDocx('Malayalam_Translation', translatedText)}
                disabled={!translatedText}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 disabled:opacity-40 transition-colors"
                title="Download as DOCX"
              >
                <Download className="w-3.5 h-3.5 text-blue-600" />
                <span>DOCX</span>
              </button>
            </div>

            {/* Send to Writer */}
            <button
              onClick={() => onSendToWriter(translatedText)}
              disabled={!translatedText}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white font-medium shadow-2xs transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send to Writer</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

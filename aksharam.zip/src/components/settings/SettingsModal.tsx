import React, { useState, useEffect } from 'react';
import { 
  UserPreferences, 
  ThemeMode, 
  FontFamilyChoice, 
  KeyboardLayoutType 
} from '../../types';
import { layoutLabels } from '../../lib/keyboardLayouts';
import { 
  X, 
  Check, 
  Type, 
  Sliders, 
  Volume2, 
  Save, 
  HelpCircle, 
  CheckCircle2, 
  AlertCircle,
  Sun,
  Moon,
  Monitor,
  Download
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onUpdatePreferences,
}) => {
  const [activeTab, setActiveTab] = useState<'appearance' | 'keyboard' | 'writing' | 'about'>('appearance');
  const [geminiStatus, setGeminiStatus] = useState<boolean | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/health')
        .then((r) => r.json())
        .then((data) => setGeminiStatus(data.geminiConfigured))
        .catch(() => setGeminiStatus(false));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl max-w-xl w-full flex flex-col overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 px-6 border-b border-stone-100 dark:border-stone-800">
          <div>
            <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
              Preferences &amp; Settings
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              Customize Malayalam typography, keyboard layouts, and behavior
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-stone-100 dark:border-stone-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('appearance')}
            className={`pb-2.5 px-2 border-b-2 transition-all ${
              activeTab === 'appearance'
                ? 'border-rose-600 text-rose-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
            }`}
          >
            Appearance &amp; Fonts
          </button>

          <button
            onClick={() => setActiveTab('keyboard')}
            className={`pb-2.5 px-2 border-b-2 transition-all ${
              activeTab === 'keyboard'
                ? 'border-rose-600 text-rose-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
            }`}
          >
            Keyboard &amp; Typing
          </button>

          <button
            onClick={() => setActiveTab('writing')}
            className={`pb-2.5 px-2 border-b-2 transition-all ${
              activeTab === 'writing'
                ? 'border-rose-600 text-rose-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
            }`}
          >
            Writing &amp; Services
          </button>

          <button
            onClick={() => setActiveTab('about')}
            className={`pb-2.5 px-2 border-b-2 transition-all ${
              activeTab === 'about'
                ? 'border-rose-600 text-rose-600 font-semibold'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
            }`}
          >
            About
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-stone-700 dark:text-stone-300">
          {activeTab === 'appearance' && (
            <>
              {/* Theme */}
              <div>
                <label className="font-semibold block mb-2 text-stone-900 dark:text-stone-100">
                  Application Theme (തീം ക്രമീകരണം)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'light', label: 'Light', ml: 'ലൈറ്റ്', icon: Sun, iconColor: 'text-amber-500' },
                    { id: 'dark', label: 'Dark', ml: 'ഡാർക്ക്', icon: Moon, iconColor: 'text-sky-400' },
                    { id: 'system', label: 'System', ml: 'സിസ്റ്റം', icon: Monitor, iconColor: 'text-stone-500' },
                  ].map(({ id, label, ml, icon: Icon, iconColor }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onUpdatePreferences({ theme: id as ThemeMode })}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all text-center ${
                        preferences.theme === id
                          ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold ring-1 ring-rose-500/20'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${iconColor}`} />
                      <span className="text-xs font-medium">{label}</span>
                      <span className="text-[10px] opacity-70">{ml}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Family */}
              <div>
                <label className="font-semibold block mb-2 text-stone-900 dark:text-stone-100">
                  Malayalam Font Family (അക്ഷരരൂപം)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      'Noto Sans Malayalam',
                      'Noto Serif Malayalam',
                      'Manjari',
                      'Gayathri',
                    ] as FontFamilyChoice[]
                  ).map((f) => (
                    <button
                      key={f}
                      onClick={() => onUpdatePreferences({ fontFamily: f })}
                      className={`p-3 rounded-xl border text-left transition-colors ${
                        preferences.fontFamily === f
                          ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800'
                      }`}
                    >
                      <div className="font-medium text-stone-900 dark:text-stone-100">
                        {f}
                      </div>
                      <div className="text-sm mt-1 opacity-80" style={{ fontFamily: f }}>
                        മലയാളം എഴുത്തുപുര
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Size */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-semibold text-stone-900 dark:text-stone-100">
                    Editor Font Size
                  </label>
                  <span className="font-mono font-medium">{preferences.fontSize}px</span>
                </div>
                <input
                  type="range"
                  min={14}
                  max={28}
                  step={1}
                  value={preferences.fontSize}
                  onChange={(e) => onUpdatePreferences({ fontSize: Number(e.target.value) })}
                  className="w-full accent-rose-600"
                />
              </div>

              {/* Editor Width */}
              <div>
                <label className="font-semibold block mb-2 text-stone-900 dark:text-stone-100">
                  Editor Page Width
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['narrow', 'medium', 'wide', 'full'] as const).map((w) => (
                    <button
                      key={w}
                      onClick={() => onUpdatePreferences({ editorWidth: w })}
                      className={`py-2 px-1 rounded-xl border text-center capitalize transition-colors ${
                        preferences.editorWidth === w
                          ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'keyboard' && (
            <>
              {/* Default Keyboard Layout */}
              <div>
                <label className="font-semibold block mb-2 text-stone-900 dark:text-stone-100">
                  Default Malayalam Keyboard Layout
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    ['inscript', 'gist', 'typewriter', 'panchari', 'varityper', 'english'] as KeyboardLayoutType[]
                  ).map((l) => (
                    <button
                      key={l}
                      onClick={() => onUpdatePreferences({ keyboardLayout: l })}
                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between ${
                        preferences.keyboardLayout === l
                          ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold'
                          : 'border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800'
                      }`}
                    >
                      <span>{layoutLabels[l]}</span>
                      {preferences.keyboardLayout === l && <Check className="w-4 h-4 text-rose-600" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Typing Sound */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
                <div className="flex items-center gap-2.5">
                  <Volume2 className="w-4 h-4 text-stone-500" />
                  <div>
                    <div className="font-semibold text-stone-900 dark:text-stone-100">
                      Keyboard Typing Sound
                    </div>
                    <div className="text-[11px] text-stone-400">
                      Gentle acoustic feedback on key press
                    </div>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.keyboardSound}
                  onChange={(e) => onUpdatePreferences({ keyboardSound: e.target.checked })}
                  className="w-4 h-4 accent-rose-600"
                />
              </div>

              {/* Show Keyboard on startup */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
                <div>
                  <div className="font-semibold text-stone-900 dark:text-stone-100">
                    Show On-Screen Keyboard on Start
                  </div>
                  <div className="text-[11px] text-stone-400">
                    Keep keyboard visible when opening the app
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.showKeyboard}
                  onChange={(e) => onUpdatePreferences({ showKeyboard: e.target.checked })}
                  className="w-4 h-4 accent-rose-600"
                />
              </div>
            </>
          )}

          {activeTab === 'writing' && (
            <>
              {/* Autosave */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
                <div className="flex items-center gap-2.5">
                  <Save className="w-4 h-4 text-stone-500" />
                  <div>
                    <div className="font-semibold text-stone-900 dark:text-stone-100">
                      Autosave to Local Storage
                    </div>
                    <div className="text-[11px] text-stone-400">
                      Automatically saves document state while typing
                    </div>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.autosaveEnabled}
                  onChange={(e) => onUpdatePreferences({ autosaveEnabled: e.target.checked })}
                  className="w-4 h-4 accent-rose-600"
                />
              </div>

              {/* Gemini Translation Status */}
              <div className="p-3.5 rounded-xl border border-stone-200 dark:border-stone-700 space-y-2">
                <div className="font-semibold text-stone-900 dark:text-stone-100">
                  Translation &amp; OCR Engine Status
                </div>
                {geminiStatus ? (
                  <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Gemini AI Connected (Multi-lingual &amp; OCR active)</span>
                  </div>
                ) : (
                  <div className="flex items-start gap-2 text-stone-600 dark:text-stone-400">
                    <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <span>Server-side fallback mode active.</span>
                      <div className="text-[11px] text-stone-400 mt-0.5">
                        Configure GEMINI_API_KEY in the environment secrets to enable AI translation and full multimodal OCR.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {activeTab === 'about' && (
            <div className="space-y-4">
              <div className="p-4 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-200 dark:border-stone-700">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-red-500 text-white flex items-center justify-center font-serif font-bold text-lg shadow-sm">
                    അ
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 dark:text-stone-100 text-sm">
                      Aksharam (അക്ഷരം) v1.0
                    </h4>
                    <p className="text-xs text-stone-500">
                      Modern Malayalam Inscript Typing, Document Writing &amp; AI Translation Suite
                    </p>
                  </div>
                </div>

                <div className="mt-3 text-[11px] text-stone-500 dark:text-stone-400 space-y-1 border-t border-stone-200/60 dark:border-stone-700/60 pt-2">
                  <div>• Complete Inscript typing guide &amp; 50+ conjuncts directory</div>
                  <div>• High-quality Unicode rendering with Malayalam web typography</div>
                  <div>• Local browser persistence, DOCX/TXT/PDF export &amp; AI translation</div>
                </div>
              </div>

              {/* Download Project Source Code ZIP */}
              <div className="p-4 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/50 dark:bg-rose-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-xs text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                    <Download className="w-4 h-4 text-rose-600" />
                    Download Project Source Code (.ZIP)
                  </div>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-0.5">
                    Complete standalone codebase with instructions for running locally or pushing to GitHub.
                  </p>
                </div>
                <a
                  href="/api/download-zip"
                  download="aksharam.zip"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-sm transition-colors shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .ZIP</span>
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 px-6 bg-stone-50 dark:bg-stone-800/60 border-t border-stone-100 dark:border-stone-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

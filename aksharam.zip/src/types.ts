export type ThemeMode = 'light' | 'dark' | 'system';

export type KeyboardLayoutType = 
  | 'inscript' 
  | 'gist' 
  | 'typewriter' 
  | 'panchari' 
  | 'varityper' 
  | 'english';

export type FontFamilyChoice = 
  | 'Noto Sans Malayalam' 
  | 'Noto Serif Malayalam' 
  | 'Manjari' 
  | 'Gayathri';

export interface DocumentItem {
  id: string;
  title: string;
  content: string;
  language: string;
  wordCount: number;
  characterCount: number;
  createdAt: string;
  updatedAt: string;
  wordGoal?: number;
  missionTitle?: string;
  isMissionActive?: boolean;
}

export interface UserPreferences {
  theme: ThemeMode;
  keyboardLayout: KeyboardLayoutType;
  showKeyboard: boolean;
  fontFamily: FontFamilyChoice;
  fontSize: number; // in px, e.g. 18
  editorWidth: 'narrow' | 'medium' | 'wide' | 'full';
  keyboardSound: boolean;
  autosaveEnabled: boolean;
  defaultSourceLanguage: string;
  showMissionTracker?: boolean;
  defaultWordGoal?: number;
}

export interface KeyDefinition {
  code: string;
  label?: string;
  normal: string;
  shift?: string;
  alt?: string;
  width?: string;
  isSpecial?: boolean;
}

export interface TranslationRequest {
  text: string;
  sourceLanguage: string;
  targetLanguage?: string;
}

export interface TranslationResponse {
  translatedText: string;
  detectedLanguage?: string;
  provider: string;
  isFallback?: boolean;
}

export interface OCRResponse {
  text: string;
  detectedLanguage?: string;
  provider: string;
  isFallback?: boolean;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'error' | 'info';
}
